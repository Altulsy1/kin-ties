/**
 * التقارير والإحصاءات
 */

class FamilyReports {
    constructor() {
        this.charts = {};
    }
    
    // إنشاء تقرير كامل
    generateFullReport() {
        return {
            summary: this.getSummaryReport(),
            demographic: this.getDemographicReport(),
            geographic: this.getGeographicReport(),
            familyStructure: this.getFamilyStructureReport(),
            timeline: this.getTimelineReport()
        };
    }
    
    // تقرير ملخص
    getSummaryReport() {
        const stats = window.familyData.getStatistics();
        
        return {
            totalPersons: stats.totalPersons,
            males: stats.males,
            females: stats.females,
            malePercentage: ((stats.males / stats.totalPersons) * 100).toFixed(1),
            femalePercentage: ((stats.females / stats.totalPersons) * 100).toFixed(1),
            living: stats.living,
            deceased: stats.deceased,
            averageAge: stats.averageAge,
            lastUpdate: stats.lastUpdate
        };
    }
    
    // تقرير ديموغرافي
    getDemographicReport() {
        const stats = window.familyData.getStatistics();
        const persons = window.familyData.getAllPersons();
        
        // توزيع الأعمار
        const ageDistribution = stats.ageGroups;
        
        // الحالة الاجتماعية (تقديرية)
        const maritalStatus = {
            'أعزب': 0,
            'متزوج': 0,
            'مطلق': 0,
            'أرمل': 0
        };
        
        persons.forEach(person => {
            if (person.spouseId && person.spouseId !== '0') {
                const spouse = window.familyData.getPersonById(person.spouseId);
                if (spouse && spouse.isAlive) {
                    maritalStatus['متزوج']++;
                } else {
                    maritalStatus['أرمل']++;
                }
            } else if (person.children && person.children.length > 0) {
                maritalStatus['مطلق']++;
            } else {
                maritalStatus['أعزب']++;
            }
        });
        
        // المستوى التعليمي (إذا توفرت البيانات)
        const educationLevels = {
            'ابتدائي': 0,
            'متوسط': 0,
            'ثانوي': 0,
            'جامعي': 0,
            'دراسات عليا': 0
        };
        
        persons.forEach(person => {
            if (person.education) {
                const edu = person.education.toLowerCase();
                if (edu.includes('ابتدائي')) educationLevels['ابتدائي']++;
                else if (edu.includes('متوسط')) educationLevels['متوسط']++;
                else if (edu.includes('ثانوي')) educationLevels['ثانوي']++;
                else if (edu.includes('جامعة') || edu.includes('جامعي')) educationLevels['جامعي']++;
                else if (edu.includes('ماجستير') || edu.includes('دكتوراة')) educationLevels['دراسات عليا']++;
            }
        });
        
        return {
            ageDistribution,
            maritalStatus,
            educationLevels
        };
    }
    
    // تقرير جغرافي
    getGeographicReport() {
        const stats = window.familyData.getStatistics();
        const persons = window.familyData.getAllPersons();
        
        // توزيع حسب المدينة
        const cities = {};
        persons.forEach(person => {
            if (person.birthPlace) {
                const city = person.birthPlace.split(',')[0].trim();
                cities[city] = (cities[city] || 0) + 1;
            }
        });
        
        // توزيع حسب المنطقة
        const regions = {
            'الرياض': 0,
            'مكة المكرمة': 0,
            'المدينة المنورة': 0,
            'الشرقية': 0,
            'عسير': 0,
            'تبوك': 0,
            'حائل': 0,
            'الحدود الشمالية': 0,
            'الجوف': 0,
            'جازان': 0,
            'نجران': 0,
            'الباحة': 0,
            'غير محدد': 0
        };
        
        persons.forEach(person => {
            if (person.birthPlace) {
                let found = false;
                for (const region in regions) {
                    if (person.birthPlace.includes(region)) {
                        regions[region]++;
                        found = true;
                        break;
                    }
                }
                if (!found) regions['غير محدد']++;
            } else {
                regions['غير محدد']++;
            }
        });
        
        return {
            cities,
            regions
        };
    }
    
    // تقرير هيكل العائلة
    getFamilyStructureReport() {
        const persons = window.familyData.getAllPersons();
        
        // عدد الأبناء لكل عائلة
        const childrenPerFamily = {};
        
        // البحث عن الآباء
        const fathers = persons.filter(p => p.gender === 'ذكر' && p.children && p.children.length > 0);
        const mothers = persons.filter(p => p.gender === 'انثى' && p.children && p.children.length > 0);
        
        fathers.forEach(father => {
            childrenPerFamily[father.id] = {
                father: father.fullName,
                mother: father.spouseId ? window.familyData.getPersonById(father.spouseId)?.fullName || 'غير معروف' : 'غير معروف',
                childrenCount: father.children.length
            };
        });
        
        // الأسر الأكبر
        const largestFamilies = Object.values(childrenPerFamily)
            .sort((a, b) => b.childrenCount - a.childrenCount)
            .slice(0, 10);
        
        // نسبة العائلات ذات الأطفال
        const familiesWithChildren = fathers.length + mothers.length;
        const totalFamilies = persons.filter(p => p.spouseId && p.spouseId !== '0').length / 2;
        const familiesWithChildrenPercentage = totalFamilies > 0 ? 
            ((familiesWithChildren / totalFamilies) * 100).toFixed(1) : 0;
        
        return {
            totalFamilies,
            familiesWithChildren,
            familiesWithChildrenPercentage,
            largestFamilies,
            averageChildrenPerFamily: fathers.length > 0 ? 
                (fathers.reduce((sum, f) => sum + f.children.length, 0) / fathers.length).toFixed(1) : 0
        };
    }
    
    // تقرير الخط الزمني
    getTimelineReport() {
        const persons = window.familyData.getAllPersons();
        
        // السنوات التي بها مواليد
        const birthsByYear = {};
        const deathsByYear = {};
        
        persons.forEach(person => {
            if (person.birthDate) {
                const year = new Date(person.birthDate).getFullYear();
                birthsByYear[year] = (birthsByYear[year] || 0) + 1;
            }
            
            if (person.deathDate) {
                const year = new Date(person.deathDate).getFullYear();
                deathsByYear[year] = (deathsByYear[year] || 0) + 1;
            }
        });
        
        // تنظيف البيانات
        const cleanBirths = this.cleanYearData(birthsByYear);
        const cleanDeaths = this.cleanYearData(deathsByYear);
        
        // العقد الأكثر مواليداً
        const birthsByDecade = {};
        Object.keys(cleanBirths).forEach(year => {
            const decade = Math.floor(year / 10) * 10;
            birthsByDecade[decade] = (birthsByDecade[decade] || 0) + cleanBirths[year];
        });
        
        return {
            birthsByYear: cleanBirths,
            deathsByYear: cleanDeaths,
            birthsByDecade,
            totalBirths: Object.values(cleanBirths).reduce((a, b) => a + b, 0),
            totalDeaths: Object.values(cleanDeaths).reduce((a, b) => a + b, 0)
        };
    }
    
    // تنظيف بيانات السنوات
    cleanYearData(yearData) {
        const cleaned = {};
        Object.keys(yearData)
            .map(y => parseInt(y))
            .sort((a, b) => a - b)
            .forEach(year => {
                cleaned[year] = yearData[year];
            });
        return cleaned;
    }
    
    // إنشاء رسوم بيانية
    createCharts() {
        this.destroyCharts(); // إزالة الرسوم القديمة
        
        const reports = this.generateFullReport();
        
        // 1. مخطط توزيع الجنسين
        this.createGenderChart(reports.summary);
        
        // 2. مخطط توزيع الأعمار
        this.createAgeChart(reports.demographic.ageDistribution);
        
        // 3. مخطط توزيع المناطق
        this.createRegionChart(reports.geographic.regions);
        
        // 4. مخطط الخط الزمني للمواليد
        this.createTimelineChart(reports.timeline.birthsByYear);
        
        // 5. مخطط الحالة الاجتماعية
        this.createMaritalStatusChart(reports.demographic.maritalStatus);
        
        // 6. مخطط المستوى التعليمي
        this.createEducationChart(reports.demographic.educationLevels);
    }
    
    // مخطط توزيع الجنسين
    createGenderChart(summary) {
        const ctx = document.getElementById('genderChart');
        if (!ctx) return;
        
        this.charts.gender = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['ذكور', 'إناث'],
                datasets: [{
                    data: [summary.males, summary.females],
                    backgroundColor: ['#3498db', '#e74c3c'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        rtl: true
                    },
                    title: {
                        display: true,
                        text: 'توزيع الجنسين',
                        font: {
                            size: 16
                        }
                    }
                }
            }
        });
    }
    
    // مخطط توزيع الأعمار
    createAgeChart(ageDistribution) {
        const ctx = document.getElementById('ageChart');
        if (!ctx) return;
        
        const labels = Object.keys(ageDistribution);
        const data = Object.values(ageDistribution);
        
        this.charts.age = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'عدد الأفراد',
                    data: data,
                    backgroundColor: '#2ecc71',
                    borderColor: '#27ae60',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'عدد الأفراد'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'مجموعات العمر'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'توزيع الأفراد حسب العمر',
                        font: {
                            size: 16
                        }
                    }
                }
            }
        });
    }
    
    // مخطط توزيع المناطق
    createRegionChart(regions) {
        const ctx = document.getElementById('regionChart');
        if (!ctx) return;
        
        const labels = Object.keys(regions).filter(r => regions[r] > 0);
        const data = Object.values(regions).filter((v, i) => labels[i]);
        
        this.charts.region = new Chart(ctx, {
            type: 'polarArea',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#3498db', '#e74c3c', '#2ecc71', '#f39c12',
                        '#9b59b6', '#1abc9c', '#d35400', '#34495e',
                        '#16a085', '#8e44ad', '#2c3e50', '#7f8c8d',
                        '#95a5a6'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                        rtl: true
                    },
                    title: {
                        display: true,
                        text: 'توزيع الأفراد حسب المناطق',
                        font: {
                            size: 16
                        }
                    }
                }
            }
        });
    }
    
    // مخطط الخط الزمني
    createTimelineChart(birthsByYear) {
        const ctx = document.getElementById('timelineChart');
        if (!ctx) return;
        
        const labels = Object.keys(birthsByYear);
        const data = Object.values(birthsByYear);
        
        this.charts.timeline = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'عدد المواليد',
                    data: data,
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'عدد المواليد'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'السنة'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'تطور عدد المواليد عبر السنين',
                        font: {
                            size: 16
                        }
                    }
                }
            }
        });
    }
    
    // مخطط الحالة الاجتماعية
    createMaritalStatusChart(maritalStatus) {
        const ctx = document.getElementById('maritalChart');
        if (!ctx) return;
        
        const labels = Object.keys(maritalStatus);
        const data = Object.values(maritalStatus);
        
        this.charts.marital = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: ['#3498db', '#e74c3c', '#2ecc71', '#f39c12']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        rtl: true
                    },
                    title: {
                        display: true,
                        text: 'توزيع الحالة الاجتماعية',
                        font: {
                            size: 16
                        }
                    }
                }
            }
        });
    }
    
    // مخطط المستوى التعليمي
    createEducationChart(educationLevels) {
        const ctx = document.getElementById('educationChart');
        if (!ctx) return;
        
        const labels = Object.keys(educationLevels).filter(l => educationLevels[l] > 0);
        const data = Object.values(educationLevels).filter((v, i) => labels[i]);
        
        this.charts.education = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'عدد الأفراد',
                    data: data,
                    backgroundColor: '#9b59b6',
                    borderColor: '#8e44ad',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                indexAxis: 'y',
                scales: {
                    x: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'عدد الأفراد'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'توزيع المستوى التعليمي',
                        font: {
                            size: 16
                        }
                    }
                }
            }
        });
    }
    
    // تدمير جميع الرسوم البيانية
    destroyCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart) {
                chart.destroy();
            }
        });
        this.charts = {};
    }
    
    // تصدير التقارير إلى Excel
    exportToExcel() {
        try {
            window.utils.showLoading('جاري إنشاء ملف Excel...');
            
            const report = this.generateFullReport();
            let csvContent = '';
            
            // 1. ملخص
            csvContent += 'التقرير الملخص\n';
            csvContent += 'المعيار,القيمة\n';
            Object.entries(report.summary).forEach(([key, value]) => {
                csvContent += `${key},${value}\n`;
            });
            csvContent += '\n\n';
            
            // 2. ديموغرافي - توزيع الأعمار
            csvContent += 'توزيع الأفراد حسب العمر\n';
            csvContent += 'مجموعة العمر,عدد الأفراد\n';
            Object.entries(report.demographic.ageDistribution).forEach(([group, count]) => {
                csvContent += `${group},${count}\n`;
            });
            csvContent += '\n\n';
            
            // 3. جغرافي - توزيع المناطق
            csvContent += 'توزيع الأفراد حسب المناطق\n';
            csvContent += 'المنطقة,عدد الأفراد\n';
            Object.entries(report.geographic.regions).forEach(([region, count]) => {
                csvContent += `${region},${count}\n`;
            });
            csvContent += '\n\n';
            
            // 4. هيكل العائلة - أكبر العائلات
            csvContent += 'أكبر 10 عائلات (حسب عدد الأبناء)\n';
            csvContent += 'الترتيب,الأب,الأم,عدد الأبناء\n';
            report.familyStructure.largestFamilies.forEach((family, index) => {
                csvContent += `${index + 1},${family.father},${family.mother},${family.childrenCount}\n`;
            });
            
            // إنشاء ملف CSV
            const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `تقرير_العائلة_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            window.utils.hideLoading();
            window.utils.showNotification('تم إنشاء ملف Excel بنجاح', 'success');
            
        } catch (error) {
            window.utils.hideLoading();
            window.utils.showNotification('حدث خطأ أثناء إنشاء ملف Excel', 'error');
            console.error('Excel Export Error:', error);
        }
    }
    
    // طباعة التقرير
    printReport() {
        const reportContent = document.getElementById('reportsContent');
        if (!reportContent) return;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="UTF-8">
                <title>تقرير عائلة محمد عبدالرحمن</title>
                <style>
                    body {
                        font-family: 'Arial', sans-serif;
                        line-height: 1.6;
                        margin: 30px;
                        text-align: right;
                        direction: rtl;
                    }
                    h1, h2, h3 {
                        color: #2c3e50;
                    }
                    .report-section {
                        margin-bottom: 30px;
                        padding: 20px;
                        border: 1px solid #ddd;
                        border-radius: 5px;
                    }
                    .stats-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                        gap: 15px;
                        margin: 20px 0;
                    }
                    .stat-card {
                        border: 1px solid #3498db;
                        padding: 15px;
                        text-align: center;
                        border-radius: 5px;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin: 20px 0;
                    }
                    th, td {
                        border: 1px solid #ddd;
                        padding: 10px;
                        text-align: right;
                    }
                    th {
                        background-color: #f8f9fa;
                    }
                    .print-header {
                        text-align: center;
                        border-bottom: 2px solid #2c3e50;
                        padding-bottom: 20px;
                        margin-bottom: 30px;
                    }
                    @media print {
                        body {
                            margin: 10px;
                        }
                        .no-print {
                            display: none;
                        }
                    }
                </style>
            </head>
            <body>
                ${reportContent.innerHTML}
            </body>
            </html>
        `);
        
        printWindow.document.close();
        printWindow.focus();
        
        setTimeout(() => {
            printWindow.print();
        }, 1000);
    }
}

// التهيئة
function initReports() {
    const familyReports = new FamilyReports();
    
    // إنشاء الرسوم البيانية عند فتح صفحة التقارير
    const createChartsBtn = document.getElementById('createChartsBtn');
    if (createChartsBtn) {
        createChartsBtn.addEventListener('click', () => {
            familyReports.createCharts();
            window.utils.showNotification('تم إنشاء الرسوم البيانية', 'success');
        });
    }
    
    // تصدير إلى Excel
    const exportExcelBtn = document.getElementById('exportExcelBtn');
    if (exportExcelBtn) {
        exportExcelBtn.addEventListener('click', () => {
            window.utils.showConfirm('هل تريد إنشاء ملف Excel للتقرير؟', 'تصدير إلى Excel')
                .then(confirmed => {
                    if (confirmed) {
                        familyReports.exportToExcel();
                    }
                });
        });
    }
    
    // طباعة التقرير
    const printReportBtn = document.getElementById('printReportBtn');
    if (printReportBtn) {
        printReportBtn.addEventListener('click', () => {
            familyReports.printReport();
        });
    }
    
    // تحديث التقارير
    const refreshReportsBtn = document.getElementById('refreshReportsBtn');
    if (refreshReportsBtn) {
        refreshReportsBtn.addEventListener('click', () => {
            window.utils.showLoading('جاري تحديث التقارير...');
            setTimeout(() => {
                familyReports.createCharts();
                window.utils.hideLoading();
                window.utils.showNotification('تم تحديث التقارير', 'success');
            }, 500);
        });
    }
    
    // إنشاء الرسوم البيانية تلقائياً عند فتح الصفحة
    setTimeout(() => {
        if (document.getElementById('reportsContent')) {
            familyReports.createCharts();
        }
    }, 1500);
}

// تصدير الفئة
window.FamilyReports = FamilyReports;

// التهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initReports);