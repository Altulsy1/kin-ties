/**
 * أدوات مساعدة لنظام شجرة العائلة
 */

// تهيئة التاريخ والتوقيت
function initDateTime() {
    const now = new Date();
    const options = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    };
    document.getElementById('currentDate').textContent = now.toLocaleDateString('ar-SA', options);
}

// تحويل التاريخ الميلادي إلى هجري
function convertToHijri(gregorianDate) {
    if (!gregorianDate) return '';
    
    try {
        const date = new Date(gregorianDate);
        const hijri = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        }).format(date);
        return hijri;
    } catch (error) {
        console.error('خطأ في تحويل التاريخ:', error);
        return '';
    }
}

// حساب العمر
function calculateAge(birthDate, deathDate = null) {
    if (!birthDate) return 'غير معروف';
    
    const birth = new Date(birthDate);
    const end = deathDate ? new Date(deathDate) : new Date();
    
    let years = end.getFullYear() - birth.getFullYear();
    let months = end.getMonth() - birth.getMonth();
    
    if (months < 0) {
        years--;
        months += 12;
    }
    
    if (deathDate) {
        return `توفي عن عمر ${years} سنة و ${months} شهر`;
    }
    
    return `${years} سنة`;
}

// عرض رسالة تنبيه
function showNotification(message, type = 'info', duration = 3000) {
    const container = document.getElementById('notificationsContainer');
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-icon">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 
                          type === 'error' ? 'fa-exclamation-circle' : 
                          type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'}"></i>
        </div>
        <div class="notification-content">
            <p>${message}</p>
        </div>
        <button class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(notification);
    
    // إضافة تأثير الظهور
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // إغلاق الرسالة
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.classList.remove('show');
        setTimeout(() => {
            container.removeChild(notification);
        }, 300);
    });
    
    // إغلاق تلقائي
    if (duration > 0) {
        setTimeout(() => {
            if (notification.parentNode) {
                notification.classList.remove('show');
                setTimeout(() => {
                    if (notification.parentNode) {
                        container.removeChild(notification);
                    }
                }, 300);
            }
        }, duration);
    }
}

// عرض شاشة التحميل
function showLoading(text = 'جاري التحميل...') {
    const loadingScreen = document.getElementById('loadingScreen');
    const loadingText = document.getElementById('loadingText');
    
    loadingText.textContent = text;
    loadingScreen.style.display = 'flex';
}

// إخفاء شاشة التحميل
function hideLoading() {
    const loadingScreen = document.getElementById('loadingScreen');
    setTimeout(() => {
        loadingScreen.style.display = 'none';
    }, 300);
}

// فتح نافذة التأكيد
function showConfirm(message, title = 'تأكيد الإجراء') {
    return new Promise((resolve) => {
        const confirmModal = document.getElementById('confirmModal');
        const confirmTitle = document.getElementById('confirmTitle');
        const confirmMessage = document.getElementById('confirmMessage');
        const confirmCancel = document.getElementById('confirmCancel');
        const confirmOk = document.getElementById('confirmOk');
        
        confirmTitle.textContent = title;
        confirmMessage.textContent = message;
        confirmModal.style.display = 'flex';
        
        confirmCancel.onclick = () => {
            confirmModal.style.display = 'none';
            resolve(false);
        };
        
        confirmOk.onclick = () => {
            confirmModal.style.display = 'none';
            resolve(true);
        };
        
        // إغلاق بالنقر خارج النافذة
        confirmModal.onclick = (e) => {
            if (e.target === confirmModal) {
                confirmModal.style.display = 'none';
                resolve(false);
            }
        };
    });
}

// تهيئة القائمة الجانبية
function initSidebar() {
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuToggle.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        document.querySelector('.main-content').classList.toggle('expanded');
    });
    
    menuItems.forEach(item => {
        item.addEventListener('click', () => {
            // إزالة النشاط من جميع العناصر
            menuItems.forEach(i => i.classList.remove('active'));
            // إضافة النشاط للعنصر الحالي
            item.classList.add('active');
            
            // إغلاق القائمة الجانبية في الجوال
            if (window.innerWidth <= 768) {
                sidebar.classList.add('collapsed');
                document.querySelector('.main-content').classList.remove('expanded');
            }
        });
    });
}

// فتح وإغلاق المودال
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'flex';
    
    // منع التمرير خلف المودال
    document.body.style.overflow = 'hidden';
    
    // إغلاق بالنقر خارج المحتوى
    modal.onclick = (e) => {
        if (e.target === modal) {
            closeModal(modalId);
        }
    };
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// تحقق من صحة البريد الإلكتروني
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// تحقق من صحة رقم الهاتف
function validatePhone(phone) {
    const re = /^[\+]?[0-9]{10,15}$/;
    return re.test(phone);
}

// توليد معرف فريد
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// تهيئة الحقول الرقمية
function initNumberInputs() {
    document.querySelectorAll('input[type="number"]').forEach(input => {
        input.addEventListener('input', (e) => {
            let value = e.target.value;
            value = value.replace(/[^\d]/g, '');
            e.target.value = value;
        });
    });
}

// تهيئة القوائم المنسدلة مع البحث
function initSelectWithSearch(selectElement) {
    const wrapper = document.createElement('div');
    wrapper.className = 'select-search-wrapper';
    
    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.className = 'select-search-input';
    searchInput.placeholder = 'ابحث...';
    
    const optionsContainer = document.createElement('div');
    optionsContainer.className = 'select-options';
    
    selectElement.parentNode.insertBefore(wrapper, selectElement);
    wrapper.appendChild(selectElement);
    wrapper.appendChild(searchInput);
    wrapper.appendChild(optionsContainer);
    
    // إظهار/إخفاء البحث بناءً على عدد الخيارات
    if (selectElement.options.length > 10) {
        searchInput.style.display = 'block';
    } else {
        searchInput.style.display = 'none';
    }
    
    // تنفيذ البحث
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        Array.from(selectElement.options).forEach(option => {
            option.style.display = option.text.toLowerCase().includes(searchTerm) ? '' : 'none';
        });
    });
}

// تهيئة جميع الأدوات
function initUtils() {
    initDateTime();
    initSidebar();
    initNumberInputs();
    
    // تحديث التاريخ كل دقيقة
    setInterval(initDateTime, 60000);
}

// تصدير الوظائف
window.utils = {
    initUtils,
    showNotification,
    showLoading,
    hideLoading,
    showConfirm,
    openModal,
    closeModal,
    convertToHijri,
    calculateAge,
    validateEmail,
    validatePhone,
    generateId,
    initSelectWithSearch
};

// التهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initUtils);