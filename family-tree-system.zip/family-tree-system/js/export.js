/**
 * وظائف التصدير
 * @file export.js
 * @description تصدير بيانات شجرة العائلة بأنماط مختلفة
 */

class ExportService {
    static init() {
        this.user = AuthService.getCurrentUser();
        this.familyData = FamilyDataService.loadFamilyData(this.user.id);
        
        this.setupExportForms();
        this.setupExportButtons();
        this.loadExportHistory();
    }

    static setupExportForms() {
        // نموذج تصدير JSON
        const jsonForm = document.querySelector('#export-json-form');
        if (jsonForm) {
            jsonForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.exportJSON();
            });
        }

        // نموذج تصدير PDF
        const pdfForm = document.querySelector('#export-pdf-form');
        if (pdfForm) {
            pdfForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.exportPDF();
            });
        }

        // نموذج تصدير CSV
        const csvForm = document.querySelector('#export-csv-form');
        if (csvForm) {
            csvForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.exportCSV();
            });
        }

        // نموذج تصدير الصورة
        const imageForm = document.querySelector('#export-image-form');
        if (imageForm) {
            imageForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.exportImage();
            });
        }
    }

    static setupExportButtons() {
        // زر التصدير السريع
        const quickExportBtn = document.querySelector('#quick-export');
        if (quickExportBtn) {
            quickExportBtn.addEventListener('click', () => {
                this.showQuickExportMenu();
            });
        }

        // استيراد البيانات
        const importBtn = document.querySelector('#import-data');
        if (importBtn) {
            importBtn.addEventListener('click', () => {
                this.showImportDialog();
            });
        }

        // النسخ الاحتياطي
        const backupBtn = document.querySelector('#create-backup');
        if (backupBtn) {
            backupBtn.addEventListener('click', () => {
                this.createBackup();
            });
        }
    }

    static exportJSON(options = {}) {
        try {
            const exportData = this.prepareExportData();
            
            let jsonData;
            if (options.prettyPrint) {
                jsonData = JSON.stringify(exportData, null, 2);
            } else {
                jsonData = JSON.stringify(exportData);
            }

            const blob = new Blob([jsonData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            this.downloadFile(url, `family-tree-${new Date().toISOString().split('T')[0]}.json`);
            
            this.logExport('json', exportData.members.length);
            App.showMessage('تم تصدير بيانات JSON بنجاح', 'success');
            
            return true;
        } catch (error) {
            App.showMessage('فشل في تصدير JSON: ' + error.message, 'error');
            return false;
        }
    }

    static exportPDF() {
        try {
            // في بيئة حقيقية، يمكن استخدام مكتبة مثل jsPDF
            const exportData = this.prepareExportData();
            
            // إنشاء محتوى PDF بسيط
            let pdfContent = `
                <html>
                <head>
                    <title>شجرة العائلة</title>
                    <style>
                        body { font-family: Arial, sans-serif; direction: rtl; }
                        .header { text-align: center; margin-bottom: 30px; }
                        .member { margin: 10px 0; padding: 10px; border: 1px solid #ddd; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>شجرة العائلة</h1>
                        <p>تم إنشاؤها في: ${new Date().toLocaleDateString('ar-SA')}</p>
                        <p>عدد الأعضاء: ${exportData.members.length}</p>
                    </div>
            `;

            // إضافة الأعضاء حسب الجيل
            const byGeneration = {};
            exportData.members.forEach(member => {
                const gen = member.generation || 1;
                if (!byGeneration[gen]) byGeneration[gen] = [];
                byGeneration[gen].push(member);
            });

            Object.keys(byGeneration).sort().forEach(gen => {
                pdfContent += `<h2>الجيل ${gen}</h2>`;
                byGeneration[gen].forEach(member => {
                    pdfContent += `
                        <div class="member">
                            <h3>${member.firstName} ${member.lastName}</h3>
                            ${member.birthDate ? `<p>الميلاد: ${member.birthDate}</p>` : ''}
                            ${member.birthPlace ? `<p>مكان الميلاد: ${member.birthPlace}</p>` : ''}
                        </div>
                    `;
                });
            });

            pdfContent += '</body></html>';

            // فتح نافذة جديدة للطباعة
            const printWindow = window.open('', '_blank');
            printWindow.document.write(pdfContent);
            printWindow.document.close();
            printWindow.print();

            this.logExport('pdf', exportData.members.length);
            App.showMessage('تم تحضير ملف PDF للطباعة', 'success');
            
            return true;
        } catch (error) {
            App.showMessage('فشل في إنشاء PDF: ' + error.message, 'error');
            return false;
        }
    }

    static exportCSV() {
        try {
            const exportData = this.prepareExportData();
            const csvContent = this.convertToCSV(exportData);
            
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            
            this.downloadFile(url, `family-tree-${new Date().toISOString().split('T')[0]}.csv`);
            
            this.logExport('csv', exportData.members.length);
            App.showMessage('تم تصدير ملف CSV بنجاح', 'success');
            
            return true;
        } catch (error) {
            App.showMessage('فشل في تصدير CSV: ' + error.message, 'error');
            return false;
        }
    }

    static exportImage() {
        try {
            // تصدير صورة الشجرة
            const treeContainer = document.querySelector('#tree-container');
            if (!treeContainer || treeContainer.innerHTML.includes('tree-empty-state')) {
                App.showMessage('يرجى عرض الشجرة أولاً', 'warning');
                return false;
            }

            // في بيئة حقيقية، يمكن استخدام html2canvas
            App.showMessage('هذه الميزة تحت التطوير. يمكنك استخدام لقطة الشاشة.', 'info');
            
            return false;
        } catch (error) {
            App.showMessage('فشل في تصدير الصورة: ' + error.message, 'error');
            return false;
        }
    }

    static prepareExportData() {
        const exportData = {
            metadata: {
                exportedAt: new Date().toISOString(),
                version: '1.0',
                source: 'Family Tree System',
                totalMembers: this.familyData.members.length,
                totalRelationships: this.familyData.relationships.length
            },
            familyInfo: {
                name: this.familyData.name,
                createdAt: this.familyData.createdAt,
                lastUpdated: this.familyData.metadata.lastUpdated
            },
            members: this.familyData.members.map(member => ({
                id: member.id,
                firstName: member.firstName,
                lastName: member.lastName,
                middleName: member.middleName,
                nickname: member.nickname,
                gender: member.gender,
                birthDate: member.birthDate,
                birthPlace: member.birthPlace,
                deathDate: member.deathDate,
                isDeceased: member.isDeceased,
                maritalStatus: member.maritalStatus,
                generation: member.generation,
                bio: member.bio,
                createdAt: member.createdAt,
                updatedAt: member.updatedAt
            })),
            relationships: this.familyData.relationships.map(rel => ({
                id: rel.id,
                from: rel.from,
                to: rel.to,
                type: rel.type,
                createdAt: rel.createdAt
            }))
        };

        return exportData;
    }

    static convertToCSV(data) {
        const headers = [
            'ID', 'الاسم الأول', 'اسم الأب', 'اسم الجد', 'اللقب', 
            'الجنس', 'تاريخ الميلاد', 'مكان الميلاد', 'تاريخ الوفاة',
            'متوفى', 'الحالة الاجتماعية', 'الجيل', 'ملاحظات'
        ];

        const rows = data.members.map(member => [
            member.id,
            member.firstName || '',
            member.middleName || '',
            '', // يمكن إضافة اسم الجد إذا كان متوفراً
            member.lastName || '',
            member.gender === 'male' ? 'ذكر' : member.gender === 'female' ? 'أنثى' : '',
            member.birthDate || '',
            member.birthPlace || '',
            member.deathDate || '',
            member.isDeceased ? 'نعم' : 'لا',
            this.getMaritalStatusLabel(member.maritalStatus) || '',
            member.generation || '',
            member.bio ? member.bio.substring(0, 100) + '...' : ''
        ]);

        const csvContent = [
            '\ufeff' + headers.join(','), // BOM لضبط الترميز
            ...rows.map(row => row.map(cell => 
                `"${cell.toString().replace(/"/g, '""')}"`
            ).join(','))
        ].join('\n');

        return csvContent;
    }

    static getMaritalStatusLabel(status) {
        const labels = {
            'single': 'أعزب',
            'married': 'متزوج',
            'divorced': 'مطلق',
            'widowed': 'أرمل'
        };
        return labels[status] || status;
    }

    static downloadFile(url, filename) {
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.style.display = 'none';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // تحرير الذاكرة
        setTimeout(() => URL.revokeObjectURL(url), 100);
    }

    static showQuickExportMenu() {
        const menuHtml = `
            <div class="quick-export-menu">
                <h4>تصدير سريع</h4>
                <div class="export-options">
                    <button class="export-option" data-format="json">
                        <span class="icon">📄</span>
                        <span class="text">JSON</span>
                    </button>
                    <button class="export-option" data-format="csv">
                        <span class="icon">📊</span>
                        <span class="text">CSV</span>
                    </button>
                    <button class="export-option" data-format="pdf">
                        <span class="icon">📃</span>
                        <span class="text">PDF</span>
                    </button>
                    <button class="export-option" data-format="print">
                        <span class="icon">🖨️</span>
                        <span class="text">طباعة</span>
                    </button>
                </div>
            </div>
        `;

        const menu = document.createElement('div');
        menu.className = 'modal-overlay';
        menu.innerHTML = menuHtml;
        
        document.body.appendChild(menu);
        
        menu.querySelectorAll('.export-option').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const format = e.currentTarget.getAttribute('data-format');
                menu.remove();
                
                switch(format) {
                    case 'json':
                        this.exportJSON({ prettyPrint: true });
                        break;
                    case 'csv':
                        this.exportCSV();
                        break;
                    case 'pdf':
                        this.exportPDF();
                        break;
                    case 'print':
                        window.print();
                        break;
                }
            });
        });
        
        menu.addEventListener('click', (e) => {
            if (e.target === menu) {
                menu.remove();
            }
        });
    }

    static showImportDialog() {
        const dialogHtml = `
            <div class="import-dialog">
                <div class="dialog-header">
                    <h3>استيراد البيانات</h3>
                    <button class="btn-close-dialog">&times;</button>
                </div>
                <div class="dialog-body">
                    <div class="import-options">
                        <div class="import-option">
                            <input type="radio" id="import-json" name="import-type" value="json" checked>
                            <label for="import-json">
                                <span class="icon">📄</span>
                                <span class="text">ملف JSON</span>
                            </label>
                        </div>
                        <div class="import-option">
                            <input type="radio" id="import-csv" name="import-type" value="csv">
                            <label for="import-csv">
                                <span class="icon">📊</span>
                                <span class="text">ملف CSV</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="file-input-container">
                        <input type="file" id="import-file" accept=".json,.csv" class="hidden">
                        <label for="import-file" class="file-input-label">
                            <span class="icon">📁</span>
                            <span class="text">اختر ملف للاستيراد</span>
                        </label>
                        <div id="selected-file-name"></div>
                    </div>
                    
                    <div class="import-options-checkbox">
                        <label>
                            <input type="checkbox" id="merge-data" checked>
                            دمج البيانات مع البيانات الحالية
                        </label>
                        <label>
                            <input type="checkbox" id="backup-before-import">
                            إنشاء نسخة احتياطية قبل الاستيراد
                        </label>
                    </div>
                </div>
                <div class="dialog-footer">
                    <button class="btn btn-secondary" id="cancel-import">إلغاء</button>
                    <button class="btn btn-primary" id="confirm-import" disabled>استيراد</button>
                </div>
            </div>
        `;

        const dialog = document.createElement('div');
        dialog.className = 'modal-overlay';
        dialog.innerHTML = dialogHtml;
        
        document.body.appendChild(dialog);
        
        const fileInput = dialog.querySelector('#import-file');
        const fileNameDisplay = dialog.querySelector('#selected-file-name');
        const confirmBtn = dialog.querySelector('#confirm-import');
        
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                const fileName = e.target.files[0].name;
                fileNameDisplay.textContent = `الملف المحدد: ${fileName}`;
                confirmBtn.disabled = false;
            }
        });
        
        confirmBtn.addEventListener('click', () => {
            const file = fileInput.files[0];
            const importType = dialog.querySelector('input[name="import-type"]:checked').value;
            const mergeData = dialog.querySelector('#merge-data').checked;
            const createBackup = dialog.querySelector('#backup-before-import').checked;
            
            this.importData(file, importType, mergeData, createBackup);
            dialog.remove();
        });
        
        dialog.querySelector('#cancel-import').addEventListener('click', () => {
            dialog.remove();
        });
        
        dialog.querySelector('.btn-close-dialog').addEventListener('click', () => {
            dialog.remove();
        });
        
        dialog.addEventListener('click', (e) => {
            if (e.target === dialog) {
                dialog.remove();
            }
        });
    }

    static async importData(file, type, mergeData, createBackup) {
        try {
            if (createBackup) {
                FamilyDataService.createBackup(this.user.id, this.familyData);
            }

            const fileContent = await this.readFile(file);
            let importedData;

            switch(type) {
                case 'json':
                    importedData = JSON.parse(fileContent);
                    break;
                case 'csv':
                    importedData = this.parseCSV(fileContent);
                    break;
                default:
                    throw new Error('نوع الملف غير مدعوم');
            }

            // التحقق من صحة البيانات
            if (!this.validateImportData(importedData, type)) {
                throw new Error('بيانات غير صالحة للاستيراد');
            }

            // معالجة البيانات المستوردة
            const processedData = this.processImportedData(importedData, type, mergeData);
            
            // حفظ البيانات
            FamilyDataService.saveFamilyData(this.user.id, processedData);
            
            // تحديث التطبيق
            if (window.App) {
                App.familyData = processedData;
                if (typeof FamilyDataUI !== 'undefined') FamilyDataUI.loadFamilyMembers();
                if (typeof TreeView !== 'undefined') TreeView.refresh();
                if (typeof FamilyMap !== 'undefined') FamilyMap.refresh();
            }

            this.logImport(type, processedData.members.length);
            App.showMessage('تم استيراد البيانات بنجاح', 'success');
            
            return true;
        } catch (error) {
            App.showMessage('فشل في استيراد البيانات: ' + error.message, 'error');
            return false;
        }
    }

    static readFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = (e) => reject(new Error('فشل في قراءة الملف'));
            reader.readAsText(file);
        });
    }

    static parseCSV(csvContent) {
        const lines = csvContent.split('\n');
        const headers = lines[0].replace(/\ufeff/g, '').split(',').map(h => h.trim().replace(/"/g, ''));
        
        const members = [];
        
        for (let i = 1; i < lines.length; i++) {
            if (!lines[i].trim()) continue;
            
            const values = this.parseCSVLine(lines[i]);
            const member = {};
            
            headers.forEach((header, index) => {
                if (values[index] !== undefined) {
                    member[header] = values[index].replace(/^"|"$/g, '');
                }
            });
            
            if (Object.keys(member).length > 0) {
                members.push(member);
            }
        }
        
        return { members: members, relationships: [] };
    }

    static parseCSVLine(line) {
        const values = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            const nextChar = line[i + 1];
            
            if (char === '"' && !inQuotes) {
                inQuotes = true;
            } else if (char === '"' && inQuotes && nextChar === '"') {
                current += '"';
                i++; // تخطي الاقتباس التالي
            } else if (char === '"' && inQuotes) {
                inQuotes = false;
            } else if (char === ',' && !inQuotes) {
                values.push(current);
                current = '';
            } else {
                current += char;
            }
        }
        
        values.push(current);
        return values;
    }

    static validateImportData(data, type) {
        if (type === 'json') {
            return data && 
                   (Array.isArray(data.members) || data.members) &&
                   typeof data === 'object';
        } else if (type === 'csv') {
            return data && Array.isArray(data.members);
        }
        return false;
    }

    static processImportedData(importedData, type, mergeData) {
        if (!mergeData) {
            return {
                ...FamilyDataService.getDefaultFamilyStructure(),
                members: Array.isArray(importedData.members) ? importedData.members : importedData,
                relationships: importedData.relationships || []
            };
        }

        // دمج البيانات
        const existingData = this.familyData;
        const existingMemberIds = new Set(existingData.members.map(m => m.id));
        
        let newMembers = [];
        if (Array.isArray(importedData.members)) {
            newMembers = importedData.members.filter(m => !existingMemberIds.has(m.id));
        } else if (Array.isArray(importedData)) {
            newMembers = importedData.filter(m => !existingMemberIds.has(m.id));
        }

        const newRelationships = importedData.relationships || [];

        return {
            ...existingData,
            members: [...existingData.members, ...newMembers],
            relationships: [...existingData.relationships, ...newRelationships],
            metadata: {
                ...existingData.metadata,
                totalMembers: existingData.members.length + newMembers.length,
                lastUpdated: new Date().toISOString()
            }
        };
    }

    static createBackup() {
        const result = FamilyDataService.createBackup(this.user.id, this.familyData);
        
        if (result.success) {
            App.showMessage('تم إنشاء نسخة احتياطية بنجاح', 'success');
            this.loadExportHistory();
        } else {
            App.showMessage(result.message, 'error');
        }
    }

    static loadExportHistory() {
        const historyContainer = document.querySelector('#export-history');
        if (!historyContainer) return;

        const exports = JSON.parse(localStorage.getItem(`export-history-${this.user.id}`) || '[]');
        
        if (exports.length === 0) {
            historyContainer.innerHTML = '<div class="empty-history">لا توجد عمليات تصدير سابقة</div>';
            return;
        }

        const historyHtml = exports.slice(-10).reverse().map(exp => `
            <div class="history-item">
                <div class="history-type">${this.getExportTypeLabel(exp.type)}</div>
                <div class="history-date">${new Date(exp.timestamp).toLocaleString('ar-SA')}</div>
                <div class="history-size">${exp.memberCount} عضو</div>
                <button class="btn-download-again" data-export-id="${exp.id}">
                    تحميل مجدداً
                </button>
            </div>
        `).join('');

        historyContainer.innerHTML = historyHtml;
    }

    static getExportTypeLabel(type) {
        const labels = {
            'json': 'JSON',
            'pdf': 'PDF',
            'csv': 'CSV',
            'image': 'صورة'
        };
        return labels[type] || type;
    }

    static logExport(type, memberCount) {
        const exports = JSON.parse(localStorage.getItem(`export-history-${this.user.id}`) || '[]');
        
        exports.push({
            id: 'export_' + Date.now(),
            type: type,
            timestamp: new Date().toISOString(),
            memberCount: memberCount
        });

        localStorage.setItem(`export-history-${this.user.id}`, JSON.stringify(exports));
        this.loadExportHistory();
    }

    static logImport(type, memberCount) {
        const imports = JSON.parse(localStorage.getItem(`import-history-${this.user.id}`) || '[]');
        
        imports.push({
            id: 'import_' + Date.now(),
            type: type,
            timestamp: new Date().toISOString(),
            memberCount: memberCount
        });

        localStorage.setItem(`import-history-${this.user.id}`, JSON.stringify(imports));
    }
}

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    if (window.App && App.currentView === 'export') {
        ExportService.init();
    }
});