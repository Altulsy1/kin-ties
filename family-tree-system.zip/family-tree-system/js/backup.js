/**
 * نظام النسخ الاحتياطي والاستعادة
 */

class BackupSystem {
    constructor() {
        this.backupInterval = null;
        this.autoBackupEnabled = false;
        this.maxBackups = 10;
        this.init();
    }
    
    init() {
        this.loadSettings();
        this.setupAutoBackup();
    }
    
    // تحميل الإعدادات
    loadSettings() {
        const settings = localStorage.getItem('backupSettings');
        if (settings) {
            try {
                const parsed = JSON.parse(settings);
                this.autoBackupEnabled = parsed.autoBackupEnabled || false;
                this.maxBackups = parsed.maxBackups || 10;
            } catch (error) {
                console.error('خطأ في تحميل إعدادات النسخ الاحتياطي:', error);
            }
        }
    }
    
    // حفظ الإعدادات
    saveSettings() {
        const settings = {
            autoBackupEnabled: this.autoBackupEnabled,
            maxBackups: this.maxBackups,
            lastUpdate: new Date().toISOString()
        };
        
        localStorage.setItem('backupSettings', JSON.stringify(settings));
    }
    
    // إعداد النسخ التلقائي
    setupAutoBackup() {
        if (this.backupInterval) {
            clearInterval(this.backupInterval);
        }
        
        if (this.autoBackupEnabled) {
            // نسخ احتياطي كل ساعة
            this.backupInterval = setInterval(() => {
                this.createAutoBackup();
            }, 60 * 60 * 1000);
            
            console.log('تم تفعيل النسخ الاحتياطي التلقائي');
        }
    }
    
    // إنشاء نسخة احتياطية تلقائية
    async createAutoBackup() {
        try {
            const backup = await this.createBackup('تلقائي');
            this.saveBackup(backup);
            console.log('تم إنشاء نسخة احتياطية تلقائية');
        } catch (error) {
            console.error('خطأ في النسخ الاحتياطي التلقائي:', error);
        }
    }
    
    // إنشاء نسخة احتياطية يدوية
    async createManualBackup(name = 'يدوي') {
        try {
            window.utils.showLoading('جاري إنشاء نسخة احتياطية...');
            
            const backup = await this.createBackup(name);
            const saved = this.saveBackup(backup);
            
            if (saved) {
                window.utils.hideLoading();
                window.utils.showNotification('تم إنشاء النسخة الاحتياطية بنجاح', 'success');
                this.updateBackupList();
                return backup;
            } else {
                throw new Error('فشل في حفظ النسخة الاحتياطية');
            }
            
        } catch (error) {
            window.utils.hideLoading();
            window.utils.showNotification('حدث خطأ أثناء إنشاء النسخة الاحتياطية', 'error');
            console.error('Backup Error:', error);
            return null;
        }
    }
    
    // إنشاء بيانات النسخة الاحتياطية
    async createBackup(type) {
        const familyData = window.familyData.getAllPersons();
        
        const backup = {
            id: this.generateBackupId(),
            name: `${type}_${new Date().toLocaleDateString('ar-SA')}`,
            type: type,
            timestamp: new Date().toISOString(),
            data: familyData,
            metadata: {
                totalPersons: familyData.length,
                males: familyData.filter(p => p.gender === 'ذكر').length,
                females: familyData.filter(p => p.gender === 'انثى').length,
                version: '2.0.0'
            }
        };
        
        return backup;
    }
    
    // حفظ النسخة الاحتياطية
    saveBackup(backup) {
        try {
            const backups = this.getBackupList();
            
            // التحقق من الحد الأقصى للنسخ
            if (backups.length >= this.maxBackups) {
                // حذف أقدم نسخة
                const oldestBackup = backups.sort((a, b) => 
                    new Date(a.timestamp) - new Date(b.timestamp)
                )[0];
                
                this.deleteBackup(oldestBackup.id);
                backups.shift();
            }
            
            backups.push(backup);
            localStorage.setItem('familyBackups', JSON.stringify(backups));
            
            return true;
        } catch (error) {
            console.error('خطأ في حفظ النسخة الاحتياطية:', error);
            return false;
        }
    }
    
    // الحصول على قائمة النسخ الاحتياطية
    getBackupList() {
        const backups = localStorage.getItem('familyBackups');
        if (backups) {
            try {
                return JSON.parse(backups);
            } catch (error) {
                console.error('خطأ في تحميل قائمة النسخ الاحتياطية:', error);
                return [];
            }
        }
        return [];
    }
    
    // استعادة نسخة احتياطية
    async restoreBackup(backupId) {
        return new Promise(async (resolve, reject) => {
            try {
                const confirmed = await window.utils.showConfirm(
                    'هل أنت متأكد من استعادة هذه النسخة؟ سيتم استبدال جميع البيانات الحالية.',
                    'تأكيد الاستعادة'
                );
                
                if (!confirmed) {
                    resolve({ success: false, message: 'تم إلغاء الاستعادة' });
                    return;
                }
                
                window.utils.showLoading('جاري استعادة النسخة الاحتياطية...');
                
                const backup = this.getBackupById(backupId);
                if (!backup) {
                    throw new Error('النسخة الاحتياطية غير موجودة');
                }
                
                // تحميل البيانات
                if (backup.data && Array.isArray(backup.data)) {
                    // تخزين النسخة الحالية كنسخة احتياطية قبل الاستعادة
                    const currentBackup = await this.createBackup('قبل الاستعادة');
                    this.saveBackup(currentBackup);
                    
                    // استبدال البيانات
                    const familyData = {
                        persons: backup.data,
                        families: this.extractFamilies(backup.data),
                        lastUpdate: new Date().toISOString()
                    };
                    
                    localStorage.setItem('familyTreeData', JSON.stringify(familyData));
                    
                    // إعادة تحميل البيانات في الذاكرة
                    window.familyData.initFamilyData();
                    
                    window.utils.hideLoading();
                    window.utils.showNotification('تم استعادة النسخة الاحتياطية بنجاح', 'success');
                    
                    // إعادة تحميل الصفحة
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                    
                    resolve({ success: true, message: 'تمت الاستعادة بنجاح' });
                } else {
                    throw new Error('بيانات النسخة الاحتياطية غير صالحة');
                }
                
            } catch (error) {
                window.utils.hideLoading();
                window.utils.showNotification('حدث خطأ أثناء استعادة النسخة الاحتياطية', 'error');
                console.error('Restore Error:', error);
                reject({ success: false, message: error.message });
            }
        });
    }
    
    // حذف نسخة احتياطية
    deleteBackup(backupId) {
        try {
            const backups = this.getBackupList();
            const filteredBackups = backups.filter(backup => backup.id !== backupId);
            
            localStorage.setItem('familyBackups', JSON.stringify(filteredBackups));
            
            window.utils.showNotification('تم حذف النسخة الاحتياطية', 'success');
            this.updateBackupList();
            
            return true;
        } catch (error) {
            window.utils.showNotification('حدث خطأ أثناء حذف النسخة الاحتياطية', 'error');
            console.error('Delete Backup Error:', error);
            return false;
        }
    }
    
    // استخراج بيانات العائلات من البيانات
    extractFamilies(persons) {
        const families = [];
        const processedPairs = new Set();
        
        persons.forEach(person => {
            if (person.spouseId && person.spouseId !== '0' && person.spouseId !== person.id) {
                const pairId = [person.id, person.spouseId].sort().join('-');
                
                if (!processedPairs.has(pairId)) {
                    families.push({
                        husbandId: person.gender === 'ذكر' ? person.id : person.spouseId,
                        wifeId: person.gender === 'انثى' ? person.id : person.spouseId,
                        children: person.children || [],
                        marriageDate: new Date().toISOString().split('T')[0]
                    });
                    
                    processedPairs.add(pairId);
                }
            }
        });
        
        return families;
    }
    
    // الحصول على نسخة بواسطة المعرف
    getBackupById(backupId) {
        const backups = this.getBackupList();
        return backups.find(backup => backup.id === backupId);
    }
    
    // توليد معرف للنسخة الاحتياطية
    generateBackupId() {
        return `backup_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    // تحديث قائمة النسخ الاحتياطية في الواجهة
    updateBackupList() {
        const backupList = document.getElementById('backupList');
        if (!backupList) return;
        
        const backups = this.getBackupList();
        
        if (backups.length === 0) {
            backupList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-database fa-3x"></i>
                    <p>لا توجد نسخ احتياطية</p>
                </div>
            `;
            return;
        }
        
        // ترتيب من الأحدث إلى الأقدم
        backups.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        backupList.innerHTML = backups.map(backup => `
            <div class="backup-item" data-id="${backup.id}">
                <div class="backup-info">
                    <div class="backup-name">${backup.name}</div>
                    <div class="backup-meta">
                        <span class="backup-type ${backup.type}">${backup.type}</span>
                        <span class="backup-date">${new Date(backup.timestamp).toLocaleString('ar-SA')}</span>
                    </div>
                    <div class="backup-stats">
                        <span><i class="fas fa-users"></i> ${backup.metadata.totalPersons} فرد</span>
                        <span><i class="fas fa-male"></i> ${backup.metadata.males} ذكر</span>
                        <span><i class="fas fa-female"></i> ${backup.metadata.females} أنثى</span>
                    </div>
                </div>
                <div class="backup-actions">
                    <button class="btn btn-sm btn-primary restore-btn" title="استعادة">
                        <i class="fas fa-undo"></i> استعادة
                    </button>
                    <button class="btn btn-sm btn-secondary download-btn" title="تنزيل">
                        <i class="fas fa-download"></i> تنزيل
                    </button>
                    <button class="btn btn-sm btn-danger delete-btn" title="حذف">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
        
        // إضافة الأحداث
        this.addBackupEvents();
    }
    
    // إضافة أحداث للنسخ الاحتياطية
    addBackupEvents() {
        // استعادة
        document.querySelectorAll('.restore-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const backupItem = e.target.closest('.backup-item');
                const backupId = backupItem.dataset.id;
                
                await this.restoreBackup(backupId);
            });
        });
        
        // تنزيل
        document.querySelectorAll('.download-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const backupItem = e.target.closest('.backup-item');
                const backupId = backupItem.dataset.id;
                
                await this.downloadBackup(backupId);
            });
        });
        
        // حذف
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const backupItem = e.target.closest('.backup-item');
                const backupId = backupItem.dataset.id;
                
                const confirmed = await window.utils.showConfirm(
                    'هل أنت متأكد من حذف هذه النسخة الاحتياطية؟',
                    'تأكيد الحذف'
                );
                
                if (confirmed) {
                    this.deleteBackup(backupId);
                }
            });
        });
    }
    
    // تنزيل نسخة احتياطية
    async downloadBackup(backupId) {
        try {
            const backup = this.getBackupById(backupId);
            if (!backup) {
                throw new Error('النسخة الاحتياطية غير موجودة');
            }
            
            const dataStr = JSON.stringify(backup, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            const url = URL.createObjectURL(dataBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `backup_${backup.name}_${backupId}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            window.utils.showNotification('تم تنزيل النسخة الاحتياطية', 'success');
            
        } catch (error) {
            window.utils.showNotification('حدث خطأ أثناء تنزيل النسخة الاحتياطية', 'error');
            console.error('Download Backup Error:', error);
        }
    }
    
    // استيراد نسخة احتياطية من ملف
    importBackupFromFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = async (event) => {
                try {
                    window.utils.showLoading('جاري استيراد النسخة الاحتياطية...');
                    
                    const backupData = JSON.parse(event.target.result);
                    
                    // التحقق من صحة البيانات
                    if (!backupData.data || !Array.isArray(backupData.data)) {
                        throw new Error('ملف النسخة الاحتياطية غير صالح');
                    }
                    
                    // إضافة النسخة المستوردة
                    const backup = {
                        ...backupData,
                        id: this.generateBackupId(),
                        name: `مستوردة_${new Date().toLocaleDateString('ar-SA')}`,
                        type: 'مستوردة',
                        timestamp: new Date().toISOString()
                    };
                    
                    this.saveBackup(backup);
                    
                    window.utils.hideLoading();
                    window.utils.showNotification('تم استيراد النسخة الاحتياطية بنجاح', 'success');
                    this.updateBackupList();
                    
                    resolve({ success: true, backup });
                    
                } catch (error) {
                    window.utils.hideLoading();
                    window.utils.showNotification('ملف النسخة الاحتياطية غير صالح', 'error');
                    console.error('Import Backup Error:', error);
                    reject({ success: false, message: error.message });
                }
            };
            
            reader.onerror = () => {
                reject({ success: false, message: 'خطأ في قراءة الملف' });
            };
            
            reader.readAsText(file);
        });
    }
    
    // تفعيل/تعطيل النسخ التلقائي
    toggleAutoBackup(enabled) {
        this.autoBackupEnabled = enabled;
        this.saveSettings();
        this.setupAutoBackup();
        
        window.utils.showNotification(
            `تم ${enabled ? 'تفعيل' : 'تعطيل'} النسخ الاحتياطي التلقائي`,
            'success'
        );
    }
    
    // تصدير جميع البيانات
    exportAllData() {
        try {
            const allData = {
                familyData: {
                    persons: window.familyData.getAllPersons(),
                    families: window.familyData.importData // استخدام الوظيفة الموجودة
                },
                backups: this.getBackupList(),
                settings: {
                    autoBackupEnabled: this.autoBackupEnabled,
                    maxBackups: this.maxBackups
                },
                exportDate: new Date().toISOString(),
                version: '2.0.0'
            };
            
            const dataStr = JSON.stringify(allData, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            const url = URL.createObjectURL(dataBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `all_data_export_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            window.utils.showNotification('تم تصدير جميع البيانات بنجاح', 'success');
            
        } catch (error) {
            window.utils.showNotification('حدث خطأ أثناء تصدير البيانات', 'error');
            console.error('Export All Data Error:', error);
        }
    }
    
    // مسح جميع البيانات
    async clearAllData() {
        const confirmed = await window.utils.showConfirm(
            '⚠️ تحذير: هذا الإجراء سيمسح جميع بيانات العائلة والنسخ الاحتياطية. هل أنت متأكد؟',
            'تأكيد مسح جميع البيانات'
        );
        
        if (!confirmed) return;
        
        const confirmed2 = await window.utils.showConfirm(
            '⚠️ هذا الإجراء لا يمكن التراجع عنه. هل أنت متأكد تماماً؟',
            'تأكيد نهائي'
        );
        
        if (!confirmed2) return;
        
        try {
            // إنشاء نسخة احتياطية أخيرة
            const finalBackup = await this.createBackup('قبل_المسح');
            this.downloadBackup(finalBackup.id);
            
            // مسح جميع البيانات
            localStorage.removeItem('familyTreeData');
            localStorage.removeItem('familyBackups');
            localStorage.removeItem('backupSettings');
            
            // إعادة التهيئة
            window.familyData.initFamilyData();
            this.init();
            
            window.utils.showNotification('تم مسح جميع البيانات بنجاح', 'success');
            
            // إعادة تحميل الصفحة
            setTimeout(() => {
                window.location.reload();
            }, 2000);
            
        } catch (error) {
            window.utils.showNotification('حدث خطأ أثناء مسح البيانات', 'error');
            console.error('Clear All Data Error:', error);
        }
    }
}

// التهيئة
function initBackup() {
    const backupSystem = new BackupSystem();
    
    // تحديث قائمة النسخ عند فتح الصفحة
    setTimeout(() => {
        backupSystem.updateBackupList();
    }, 500);
    
    // إنشاء نسخة يدوية
    const createBackupBtn = document.getElementById('createBackupBtn');
    if (createBackupBtn) {
        createBackupBtn.addEventListener('click', async () => {
            const name = prompt('أدخل اسم للنسخة الاحتياطية:', `نسخة_${new Date().toLocaleDateString('ar-SA')}`);
            if (name) {
                await backupSystem.createManualBackup(name);
            }
        });
    }
    
    // استيراد نسخة من ملف
    const importBackupBtn = document.getElementById('importBackupBtn');
    if (importBackupBtn) {
        importBackupBtn.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            
            input.onchange = async (e) => {
                const file = e.target.files[0];
                if (file) {
                    await backupSystem.importBackupFromFile(file);
                }
            };
            
            input.click();
        });
    }
    
    // تصدير جميع البيانات
    const exportAllDataBtn = document.getElementById('exportAllDataBtn');
    if (exportAllDataBtn) {
        exportAllDataBtn.addEventListener('click', () => {
            window.utils.showConfirm(
                'هل تريد تصدير جميع البيانات بما في ذلك النسخ الاحتياطية؟',
                'تصدير جميع البيانات'
            ).then(confirmed => {
                if (confirmed) {
                    backupSystem.exportAllData();
                }
            });
        });
    }
    
    // مسح جميع البيانات
    const clearDataBtn = document.getElementById('clearDataBtn');
    if (clearDataBtn) {
        clearDataBtn.addEventListener('click', () => {
            backupSystem.clearAllData();
        });
    }
    
    // تفعيل/تعطيل النسخ التلقائي
    const autoBackupToggle = document.getElementById('autoBackupToggle');
    if (autoBackupToggle) {
        autoBackupToggle.checked = backupSystem.autoBackupEnabled;
        autoBackupToggle.addEventListener('change', (e) => {
            backupSystem.toggleAutoBackup(e.target.checked);
        });
    }
    
    // تحديث قائمة النسخ
    const refreshBackupsBtn = document.getElementById('refreshBackupsBtn');
    if (refreshBackupsBtn) {
        refreshBackupsBtn.addEventListener('click', () => {
            backupSystem.updateBackupList();
            window.utils.showNotification('تم تحديث قائمة النسخ الاحتياطية', 'success');
        });
    }
}

// تصدير الفئة
window.BackupSystem = BackupSystem;

// التهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initBackup);