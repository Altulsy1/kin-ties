/**
 * نظام المصادقة لنظام شجرة العائلة
 */

// بيانات المستخدمين (يمكن تخزينها في قاعدة بيانات في التطوير الحقيقي)
const users = {
    admin: {
        password: '123456',
        name: 'مدير النظام',
        role: 'admin',
        email: 'admin@familytree.com'
    },
    user: {
        password: '123456',
        name: 'مستخدم عادي',
        role: 'user',
        email: 'user@familytree.com'
    }
};

// تسجيل الدخول
function login(username, password) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = users[username];
            
            if (user && user.password === password) {
                // تخزين بيانات الجلسة
                sessionStorage.setItem('isLoggedIn', 'true');
                sessionStorage.setItem('username', username);
                sessionStorage.setItem('userRole', user.role);
                sessionStorage.setItem('userName', user.name);
                
                resolve({
                    success: true,
                    user: {
                        username,
                        name: user.name,
                        role: user.role,
                        email: user.email
                    }
                });
            } else {
                reject({
                    success: false,
                    message: 'اسم المستخدم أو كلمة المرور غير صحيحة'
                });
            }
        }, 1000); // محاكاة وقت استجابة الخادم
    });
}

// تسجيل الخروج
function logout() {
    sessionStorage.removeItem('isLoggedIn');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('userName');
    
    window.location.reload();
}

// التحقق من حالة تسجيل الدخول
function checkLoginStatus() {
    return sessionStorage.getItem('isLoggedIn') === 'true';
}

// الحصول على بيانات المستخدم الحالي
function getCurrentUser() {
    if (!checkLoginStatus()) {
        return null;
    }
    
    const username = sessionStorage.getItem('username');
    const userRole = sessionStorage.getItem('userRole');
    const userName = sessionStorage.getItem('userName');
    
    return {
        username,
        role: userRole,
        name: userName
    };
}

// التحقق من الصلاحيات
function checkPermission(requiredRole) {
    const user = getCurrentUser();
    if (!user) return false;
    
    // صلاحيات الأدوار
    const roleHierarchy = {
        'admin': ['admin', 'user'],
        'user': ['user']
    };
    
    return roleHierarchy[user.role]?.includes(requiredRole) || false;
}

// تحديث معلومات المستخدم
function updateUserProfile(username, updates) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (users[username]) {
                Object.assign(users[username], updates);
                resolve({ success: true });
            } else {
                reject({ success: false, message: 'المستخدم غير موجود' });
            }
        }, 500);
    });
}

// تغيير كلمة المرور
function changePassword(username, oldPassword, newPassword) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = users[username];
            
            if (!user) {
                reject({ success: false, message: 'المستخدم غير موجود' });
                return;
            }
            
            if (user.password !== oldPassword) {
                reject({ success: false, message: 'كلمة المرور القديمة غير صحيحة' });
                return;
            }
            
            user.password = newPassword;
            resolve({ success: true, message: 'تم تغيير كلمة المرور بنجاح' });
        }, 500);
    });
}

// إضافة مستخدم جديد (للمسؤول فقط)
function addNewUser(userData) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (users[userData.username]) {
                reject({ success: false, message: 'اسم المستخدم موجود مسبقاً' });
                return;
            }
            
            users[userData.username] = {
                password: userData.password,
                name: userData.name,
                role: userData.role || 'user',
                email: userData.email || ''
            };
            
            resolve({ success: true, message: 'تم إضافة المستخدم بنجاح' });
        }, 500);
    });
}

// حذف مستخدم (للمسؤول فقط)
function deleteUser(username) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!users[username]) {
                reject({ success: false, message: 'المستخدم غير موجود' });
                return;
            }
            
            if (username === 'admin') {
                reject({ success: false, message: 'لا يمكن حذف حساب المسؤول الرئيسي' });
                return;
            }
            
            delete users[username];
            resolve({ success: true, message: 'تم حذف المستخدم بنجاح' });
        }, 500);
    });
}

// الحصول على قائمة جميع المستخدمين
function getAllUsers() {
    return Object.entries(users).map(([username, data]) => ({
        username,
        name: data.name,
        role: data.role,
        email: data.email
    }));
}

// التهيئة
function initAuth() {
    const loginForm = document.getElementById('login-form');
    const logoutBtn = document.getElementById('logoutBtn');
    const loginScreen = document.getElementById('login-screen');
    const mainApp = document.getElementById('main-app');
    
    // التحقق من حالة تسجيل الدخول
    if (checkLoginStatus()) {
        loginScreen.style.display = 'none';
        mainApp.style.display = 'block';
        
        // عرض اسم المستخدم
        const currentUser = getCurrentUser();
        if (currentUser) {
            document.getElementById('userName').textContent = currentUser.name;
        }
    } else {
        loginScreen.style.display = 'flex';
        mainApp.style.display = 'none';
    }
    
    // معالجة تسجيل الدخول
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('login-error');
            
            // إظهار شاشة التحميل
            window.utils.showLoading('جاري التحقق...');
            
            try {
                const result = await login(username, password);
                
                if (result.success) {
                    window.utils.showNotification('تم تسجيل الدخول بنجاح', 'success');
                    
                    // إخفاء رسالة الخطأ
                    errorDiv.style.display = 'none';
                    
                    // الانتقال إلى الواجهة الرئيسية
                    setTimeout(() => {
                        loginScreen.style.display = 'none';
                        mainApp.style.display = 'block';
                        document.getElementById('userName').textContent = result.user.name;
                        
                        // إعادة تحميل الصفحة لتفعيل جميع المكونات
                        window.location.href = 'index.html';
                    }, 1000);
                }
            } catch (error) {
                window.utils.hideLoading();
                errorDiv.style.display = 'flex';
                document.getElementById('username').focus();
            }
        });
    }
    
    // معالجة تسجيل الخروج
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            window.utils.showConfirm('هل أنت متأكد من تسجيل الخروج؟', 'تأكيد الخروج')
                .then((confirmed) => {
                    if (confirmed) {
                        logout();
                    }
                });
        });
    }
    
    // حماية الصفحات
    function protectPage() {
        if (!checkLoginStatus()) {
            window.location.href = 'index.html';
        }
    }
    
    // حماية جميع الصفحات باستثناء صفحة الدخول
    if (!window.location.pathname.includes('login.html') && !window.location.pathname.endsWith('index.html')) {
        protectPage();
    }
}

// تصدير الوظائف
window.auth = {
    login,
    logout,
    checkLoginStatus,
    getCurrentUser,
    checkPermission,
    updateUserProfile,
    changePassword,
    addNewUser,
    deleteUser,
    getAllUsers,
    initAuth
};

// التهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initAuth);