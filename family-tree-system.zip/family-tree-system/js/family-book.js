/**
 * كتاب العائلة - PDF والتصدير
 */

class FamilyBook {
    constructor() {
        this.currentPage = 1;
        this.totalPages = 1;
        this.bookData = null;
    }
    
    // توليد كتاب العائلة
    generateBook() {
        this.bookData = {
            title: 'كتاب عائلة محمد عبدالرحمن',
            subtitle: 'توثيق وتاريخ العائلة عبر الأجيال',
            generatedDate: new Date().toLocaleDateString('ar-SA'),
            chapters: []
        };
        
        // الفصل الأول: مقدمة
        this.bookData.chapters.push({
            title: 'مقدمة',
            content: `
                <h2>مقدمة</h2>
                <p>يسرنا أن نقدم لكم كتاب عائلة محمد عبدالرحمن، الذي يوثق تاريخ العائلة وأفرادها عبر الأجيال. 
                هذا الكتاب يهدف إلى حفظ التراث العائلي ونقله للأجيال القادمة.</p>
                <p>تم جمع المعلومات الواردة في هذا الكتاب من مصادر موثوقة ومقابلات مع كبار العائلة، 
                ونحرص على تحديثها باستمرار للحفاظ على دقتها.</p>
            `
        });
        
        // الفصل الثاني: الجد المؤسس
        const founder = window.familyData.getAllPersons().find(p => 
            !p.fatherId || p.fatherId === '0'
        );
        
        if (founder) {
            this.bookData.chapters.push({
                title: 'الجد المؤسس',
                content: `
                    <h2>الجد المؤسس: ${founder.fullName}</h2>
                    <div class="founder-info">
                        <p><strong>مكان الميلاد:</strong> ${founder.birthPlace || 'غير معروف'}</p>
                        <p><strong>تاريخ الميلاد:</strong> ${founder.birthDate ? new Date(founder.birthDate).toLocaleDateString('ar-SA') : 'غير معروف'}</p>
                        <p><strong>المهنة:</strong> ${founder.occupation || 'غير معروف'}</p>
                        ${founder.notes ? `<p><strong>ملاحظات:</strong> ${founder.notes}</p>` : ''}
                    </div>
                `
            });
        }
        
        // الفصل الثالث: الأبناء والأحفاد
        this.bookData.chapters.push({
            title: 'الأبناء والأحفاد',
            content: this.generateDescendantsChapter()
        });
        
        // الفصل الرابع: الإحصائيات
        this.bookData.chapters.push({
            title: 'إحصائيات العائلة',
            content: this.generateStatisticsChapter()
        });
        
        // الفصل الخامس: قائمة كاملة بالأفراد
        this.bookData.chapters.push({
            title: 'قائمة الأفراد',
            content: this.generatePersonsListChapter()
        });
        
        // الفصل السادس: شجرة العائلة
        this.bookData.chapters.push({
            title: 'شجرة العائلة',
            content: this.generateFamilyTreeChapter()
        });
        
        // الفصل السابع: ذكريات ومناسبات
        this.bookData.chapters.push({
            title: 'ذكريات ومناسبات',
            content: this.generateMemoriesChapter()
        });
        
        return this.bookData;
    }
    
    // توليد فصل الأبناء والأحفاد
    generateDescendantsChapter() {
        const persons = window.familyData.getAllPersons();
        const generations = {};
        
        persons.forEach(person => {
            const depth = this.getGenerationDepth(person.id);
            if (!generations[depth]) {
                generations[depth] = [];
            }
            generations[depth].push(person);
        });
        
        let html = '<h2>الأبناء والأحفاد حسب الأجيال</h2>';
        
        Object.keys(generations).sort((a, b) => a - b).forEach(depth => {
            const generationName = this.getGenerationName(parseInt(depth));
            html += `<h3>${generationName}</h3>`;
            html += '<div class="generation-persons">';
            
            generations[depth].forEach(person => {
                html += `
                    <div class="person-card">
                        <h4>${person.fullName}</h4>
                        <p>${person.gender === 'ذكر' ? '👨' : '👩'} ${person.birthDate ? `(${window.utils.calculateAge(person.birthDate)})` : ''}</p>
                        ${person.birthPlace ? `<p>مكان الميلاد: ${person.birthPlace}</p>` : ''}
                    </div>
                `;
            });
            
            html += '</div>';
        });
        
        return html;
    }
    
    // توليد فصل الإحصائيات
    generateStatisticsChapter() {
        const stats = window.familyData.getStatistics();
        
        return `
            <h2>إحصائيات العائلة</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>إجمالي الأفراد</h3>
                    <div class="stat-number">${stats.totalPersons}</div>
                </div>
                <div class="stat-card">
                    <h3>الذكور</h3>
                    <div class="stat-number">${stats.males}</div>
                </div>
                <div class="stat-card">
                    <h3>الإناث</h3>
                    <div class="stat-number">${stats.females}</div>
                </div>
                <div class="stat-card">
                    <h3>متوسط العمر</h3>
                    <div class="stat-number">${stats.averageAge}</div>
                    <div class="stat-unit">سنة</div>
                </div>
                <div class="stat-card">
                    <h3>الأحياء</h3>
                    <div class="stat-number">${stats.living}</div>
                </div>
                <div class="stat-card">
                    <h3>المتوفين</h3>
                    <div class="stat-number">${stats.deceased}</div>
                </div>
            </div>
            
            <h3>التوزيع حسب العمر</h3>
            <div class="age-groups">
                ${Object.entries(stats.ageGroups).map(([group, count]) => `
                    <div class="age-group">
                        <span class="group-label">${group}</span>
                        <span class="group-count">${count} فرد</span>
                    </div>
                `).join('')}
            </div>
            
            <h3>التوزيع حسب مكان الميلاد</h3>
            <div class="birth-places">
                ${Object.entries(stats.birthPlaces).map(([place, count]) => `
                    <div class="birth-place">
                        <span class="place-name">${place}</span>
                        <span class="place-count">${count} فرد</span>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    // توليد قائمة الأفراد
    generatePersonsListChapter() {
        const persons = window.familyData.getAllPersons();
        
        let html = `
            <h2>قائمة كاملة بأفراد العائلة</h2>
            <div class="persons-table-container">
                <table class="persons-table">
                    <thead>
                        <tr>
                            <th>الاسم الكامل</th>
                            <th>الجنس</th>
                            <th>تاريخ الميلاد</th>
                            <th>مكان الميلاد</th>
                            <th>العمر</th>
                            <th>الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        persons.forEach(person => {
            const age = person.birthDate ? window.utils.calculateAge(person.birthDate, person.deathDate) : 'غير معروف';
            const status = person.isAlive ? 'حي' : 'متوفى';
            
            html += `
                <tr>
                    <td>${person.fullName}</td>
                    <td>${person.gender === 'ذكر' ? 'ذكر' : 'أنثى'}</td>
                    <td>${person.birthDate ? new Date(person.birthDate).toLocaleDateString('ar-SA') : 'غير معروف'}</td>
                    <td>${person.birthPlace || 'غير معروف'}</td>
                    <td>${age}</td>
                    <td><span class="status-badge ${person.isAlive ? 'alive' : 'deceased'}">${status}</span></td>
                </tr>
            `;
        });
        
        html += `
                    </tbody>
                </table>
            </div>
        `;
        
        return html;
    }
    
    // توليد فصل شجرة العائلة
    generateFamilyTreeChapter() {
        const tree = window.familyData.getFamilyTree();
        
        if (!tree) {
            return '<h2>شجرة العائلة</h2><p>لا توجد بيانات لعرض شجرة العائلة.</p>';
        }
        
        return `
            <h2>شجرة العائلة</h2>
            <div class="tree-diagram">
                ${this.generateTreeHTML(tree)}
            </div>
            <div class="tree-legend">
                <h3>مفتاح الشجرة:</h3>
                <div class="legend-item">
                    <span class="legend-male">⬤</span> ذكر
                </div>
                <div class="legend-item">
                    <span class="legend-female">⬤</span> أنثى
                </div>
                <div class="legend-item">
                    <span class="legend-living">✓</span> حي
                </div>
                <div class="legend-item">
                    <span class="legend-deceased">✗</span> متوفى
                </div>
            </div>
        `;
    }
    
    // توليد HTML للشجرة
    generateTreeHTML(node, depth = 0) {
        const person = node.person;
        const genderClass = person.gender === 'ذكر' ? 'male' : 'female';
        const statusClass = person.isAlive ? 'living' : 'deceased';
        
        let html = `
            <div class="tree-node depth-${depth}">
                <div class="node-content ${genderClass} ${statusClass}">
                    <div class="node-name">${person.fullName}</div>
                    ${person.birthDate ? `<div class="node-age">${window.utils.calculateAge(person.birthDate, person.deathDate)}</div>` : ''}
                </div>
        `;
        
        if (node.children && node.children.length > 0) {
            html += '<div class="children-container">';
            node.children.forEach(child => {
                html += this.generateTreeHTML(child, depth + 1);
            });
            html += '</div>';
        }
        
        html += '</div>';
        return html;
    }
    
    // توليد فصل الذكريات
    generateMemoriesChapter() {
        return `
            <h2>ذكريات ومناسبات العائلة</h2>
            <div class="memories-container">
                <div class="memory-card">
                    <h3>المناسبات العائلية</h3>
                    <p>تجتمع العائلة في المناسبات الدينية والأعياد، وتعقد اجتماعات دورية لمناقشة شؤون العائلة.</p>
                </div>
                <div class="memory-card">
                    <h3>التقاليد العائلية</h3>
                    <p>تحرص العائلة على الحفاظ على التقاليد والعادات الموروثة ونقلها للأجيال الجديدة.</p>
                </div>
                <div class="memory-card">
                    <h3>الإنجازات البارزة</h3>
                    <p>يتم تسجيل إنجازات أفراد العائلة في مختلف المجالات للاحتفاء بها وتشجيع الأجيال الجديدة.</p>
                </div>
            </div>
            
            <h3>صور العائلة</h3>
            <div class="family-photos">
                <p>يمكن إضافة صور العائلة هنا عند توفرها.</p>
            </div>
        `;
    }
    
    // حساب عمق الجيل
    getGenerationDepth(personId, depth = 0) {
        const person = window.familyData.getPersonById(personId);
        if (!person || !person.fatherId || person.fatherId === '0') {
            return depth;
        }
        return this.getGenerationDepth(person.fatherId, depth + 1);
    }
    
    // الحصول على اسم الجيل
    getGenerationName(depth) {
        const names = [
            'الجيل الأول (الجد المؤسس)',
            'الجيل الثاني (الأبناء)',
            'الجيل الثالث (الأحفاد)',
            'الجيل الرابع',
            'الجيل الخامس',
            'الجيل السادس',
            'الجيل السابع',
            'الجيل الثامن',
            'الجيل التاسع',
            'الجيل العاشر'
        ];
        
        return names[depth] || `الجيل ${depth + 1}`;
    }
    
    // تصدير إلى PDF
    async exportToPDF() {
        try {
            window.utils.showLoading('جاري إنشاء ملف PDF...');
            
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF({
                orientation: 'portrait',
                unit: 'mm',
                format: 'a4'
            });
            
            // إعداد الخط العربي
            doc.setFont('Arial', 'normal');
            
            let y = 20;
            const pageWidth = doc.internal.pageSize.width;
            const margin = 20;
            const contentWidth = pageWidth - (margin * 2);
            
            // عنوان الكتاب
            doc.setFontSize(24);
            doc.text('كتاب عائلة محمد عبدالرحمن', pageWidth / 2, y, { align: 'center' });
            y += 10;
            
            doc.setFontSize(14);
            doc.text('توثيق وتاريخ العائلة عبر الأجيال', pageWidth / 2, y, { align: 'center' });
            y += 15;
            
            doc.setFontSize(12);
            doc.text(`تاريخ الإنشاء: ${new Date().toLocaleDateString('ar-SA')}`, pageWidth / 2, y, { align: 'center' });
            y += 20;
            
            // إضافة الفهرس
            doc.setFontSize(16);
            doc.text('فهرس المحتويات', margin, y);
            y += 10;
            
            doc.setFontSize(12);
            const chapters = this.bookData.chapters;
            chapters.forEach((chapter, index) => {
                if (y > 270) {
                    doc.addPage();
                    y = 20;
                }
                doc.text(`${index + 1}. ${chapter.title}`, margin + 10, y);
                y += 10;
            });
            
            y += 10;
            
            // إضافة المحتوى
            for (const chapter of chapters) {
                if (y > 270) {
                    doc.addPage();
                    y = 20;
                }
                
                doc.setFontSize(18);
                doc.text(chapter.title, margin, y);
                y += 15;
                
                // تحويل HTML إلى نص عادي
                const plainText = chapter.content
                    .replace(/<[^>]*>/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();
                
                const lines = doc.splitTextToSize(plainText, contentWidth);
                
                doc.setFontSize(12);
                lines.forEach(line => {
                    if (y > 270) {
                        doc.addPage();
                        y = 20;
                    }
                    doc.text(line, margin, y);
                    y += 8;
                });
                
                y += 10;
            }
            
            // إضافة تذييل الصفحة
            const pageCount = doc.internal.getNumberOfPages();
            for (let i = 1; i <= pageCount; i++) {
                doc.setPage(i);
                doc.setFontSize(10);
                doc.text(`صفحة ${i} من ${pageCount}`, pageWidth - margin, 290, { align: 'right' });
                doc.text('كتاب عائلة محمد عبدالرحمن', margin, 290);
            }
            
            // حفظ الملف
            const fileName = `كتاب_العائلة_${new Date().toISOString().split('T')[0]}.pdf`;
            doc.save(fileName);
            
            window.utils.hideLoading();
            window.utils.showNotification('تم إنشاء ملف PDF بنجاح', 'success');
            
        } catch (error) {
            window.utils.hideLoading();
            window.utils.showNotification('حدث خطأ أثناء إنشاء ملف PDF', 'error');
            console.error('PDF Export Error:', error);
        }
    }
    
    // تصدير إلى Word
    async exportToWord() {
        try {
            window.utils.showLoading('جاري إنشاء ملف Word...');
            
            const content = `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <title>كتاب عائلة محمد عبدالرحمن</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.8;
            margin: 40px;
            text-align: right;
            direction: rtl;
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 10px;
        }
        h2 {
            color: #3498db;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
            margin-top: 30px;
        }
        .chapter {
            margin-bottom: 40px;
        }
        .person-card {
            border: 1px solid #ddd;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .stat-card {
            display: inline-block;
            border: 1px solid #3498db;
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            text-align: center;
            min-width: 120px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: right;
        }
        th {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
    ${this.generateBookHTML()}
</body>
</html>
            `;
            
            // إنشاء ملف Blob
            const blob = new Blob([content], { type: 'application/msword' });
            const url = URL.createObjectURL(blob);
            
            // إنشاء رابط للتنزيل
            const a = document.createElement('a');
            a.href = url;
            a.download = `كتاب_العائلة_${new Date().toISOString().split('T')[0]}.doc`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            
            // تحرير الذاكرة
            URL.revokeObjectURL(url);
            
            window.utils.hideLoading();
            window.utils.showNotification('تم إنشاء ملف Word بنجاح', 'success');
            
        } catch (error) {
            window.utils.hideLoading();
            window.utils.showNotification('حدث خطأ أثناء إنشاء ملف Word', 'error');
            console.error('Word Export Error:', error);
        }
    }
    
    // توليد HTML للكتاب
    generateBookHTML() {
        const book = this.generateBook();
        
        let html = `
            <h1>${book.title}</h1>
            <h2 style="text-align: center; color: #666;">${book.subtitle}</h2>
            <p style="text-align: center;">تاريخ الإنشاء: ${book.generatedDate}</p>
            <hr>
        `;
        
        book.chapters.forEach((chapter, index) => {
            html += `
                <div class="chapter">
                    <h2>${index + 1}. ${chapter.title}</h2>
                    ${chapter.content}
                </div>
            `;
        });
        
        html += `
            <hr>
            <footer style="text-align: center; color: #666; margin-top: 50px;">
                <p>كتاب عائلة محمد عبدالرحمن</p>
                <p>تم إنشاؤه بواسطة نظام إدارة شجرة العائلة</p>
                <p>© ${new Date().getFullYear()} جميع الحقوق محفوظة</p>
            </footer>
        `;
        
        return html;
    }
    
    // عرض معاينة الكتاب
    showPreview() {
        const book = this.generateBook();
        const previewContainer = document.getElementById('bookPreview');
        
        if (previewContainer) {
            previewContainer.innerHTML = this.generateBookHTML();
        }
    }
}

// تصدير الفئة
window.FamilyBook = FamilyBook;

// التهيئة
function initFamilyBook() {
    const familyBook = new FamilyBook();
    
    // عرض معاينة تلقائية
    setTimeout(() => {
        familyBook.showPreview();
    }, 1000);
    
    // تصدير PDF
    const exportPdfBtn = document.getElementById('exportPdfBtn');
    if (exportPdfBtn) {
        exportPdfBtn.addEventListener('click', () => {
            window.utils.showConfirm('هل تريد إنشاء ملف PDF لكتاب العائلة؟', 'تصدير إلى PDF')
                .then(confirmed => {
                    if (confirmed) {
                        familyBook.exportToPDF();
                    }
                });
        });
    }
    
    // تصدير Word
    const exportWordBtn = document.getElementById('exportWordBtn');
    if (exportWordBtn) {
        exportWordBtn.addEventListener('click', () => {
            window.utils.showConfirm('هل تريد إنشاء ملف Word لكتاب العائلة؟', 'تصدير إلى Word')
                .then(confirmed => {
                    if (confirmed) {
                        familyBook.exportToWord();
                    }
                });
        });
    }
    
    // تحديث المعاينة
    const refreshPreviewBtn = document.getElementById('refreshPreviewBtn');
    if (refreshPreviewBtn) {
        refreshPreviewBtn.addEventListener('click', () => {
            familyBook.showPreview();
            window.utils.showNotification('تم تحديث معاينة الكتاب', 'success');
        });
    }
}

// التهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initFamilyBook);