/**
 * إدارة بيانات العائلة
 */

// هيكل بيانات الفرد
class Person {
    constructor(data) {
        this.id = data.id || generatePersonId();
        this.fullName = data.fullName;
        this.gender = data.gender;
        this.birthPlace = data.birthPlace || '';
        this.birthDate = data.birthDate || '';
        this.deathDate = data.deathDate || '';
        this.fatherId = data.fatherId || 0;
        this.motherId = data.motherId || 0;
        this.spouseId = data.spouseId || 0;
        this.children = data.children || [];
        this.notes = data.notes || '';
        this.createdAt = data.createdAt || new Date().toISOString();
        this.updatedAt = new Date().toISOString();
        this.isAlive = data.isAlive !== false;
        this.photo = data.photo || '';
        this.contactInfo = data.contactInfo || {};
        this.education = data.education || '';
        this.occupation = data.occupation || '';
        this.address = data.address || '';
    }
}

// توليد معرف فريد للفرد
function generatePersonId() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000);
    return `P${timestamp}${random}`;
}

// بيانات العائلة الافتراضية
let familyData = {
    persons: [],
    families: [],
    lastUpdate: null
};

// تهيئة البيانات
function initFamilyData() {
    const savedData = localStorage.getItem('familyTreeData');
    
    if (savedData) {
        try {
            familyData = JSON.parse(savedData);
            console.log('تم تحميل بيانات العائلة بنجاح');
        } catch (error) {
            console.error('خطأ في تحميل البيانات:', error);
            createDefaultData();
        }
    } else {
        createDefaultData();
    }
    
    familyData.lastUpdate = new Date().toISOString();
    saveData();
}

// إنشاء بيانات افتراضية
function createDefaultData() {
    // الجد المؤسس
    const founder = new Person({
        fullName: 'محمد عبدالرحمن ادم',
        gender: 'ذكر',
        birthPlace: 'الرياض',
        birthDate: '1950-01-01',
        isAlive: true
    });
    
    // الزوجة
    const wife = new Person({
        fullName: 'فاطمة أحمد محمد',
        gender: 'انثى',
        birthPlace: 'مكة المكرمة',
        birthDate: '1955-03-15',
        isAlive: true
    });
    
    // الأبناء
    const son1 = new Person({
        fullName: 'عمر محمد عبدالرحمن',
        gender: 'ذكر',
        birthPlace: 'الرياض',
        birthDate: '1980-05-10',
        fatherId: founder.id,
        motherId: wife.id,
        isAlive: true
    });
    
    const son2 = new Person({
        fullName: 'خالد محمد عبدالرحمن',
        gender: 'ذكر',
        birthPlace: 'الرياض',
        birthDate: '1982-08-20',
        fatherId: founder.id,
        motherId: wife.id,
        isAlive: true
    });
    
    const daughter1 = new Person({
        fullName: 'سارة محمد عبدالرحمن',
        gender: 'انثى',
        birthPlace: 'الرياض',
        birthDate: '1985-11-05',
        fatherId: founder.id,
        motherId: wife.id,
        isAlive: true
    });
    
    // تحديث بيانات الزواج
    founder.spouseId = wife.id;
    wife.spouseId = founder.id;
    
    // تحديث قائمة الأطفال
    founder.children = [son1.id, son2.id, daughter1.id];
    wife.children = founder.children;
    
    familyData.persons = [founder, wife, son1, son2, daughter1];
    familyData.families = [{
        husbandId: founder.id,
        wifeId: wife.id,
        children: founder.children,
        marriageDate: '1975-06-01'
    }];
}

// حفظ البيانات
function saveData() {
    try {
        localStorage.setItem('familyTreeData', JSON.stringify(familyData));
        console.log('تم حفظ البيانات بنجاح');
        return true;
    } catch (error) {
        console.error('خطأ في حفظ البيانات:', error);
        window.utils.showNotification('حدث خطأ في حفظ البيانات', 'error');
        return false;
    }
}

// الحصول على جميع الأفراد
function getAllPersons() {
    return familyData.persons.sort((a, b) => 
        new Date(b.createdAt) - new Date(a.createdAt)
    );
}

// الحصول على فرد بواسطة المعرف
function getPersonById(id) {
    return familyData.persons.find(person => person.id === id);
}

// إضافة فرد جديد
function addPerson(personData) {
    return new Promise((resolve, reject) => {
        try {
            const newPerson = new Person(personData);
            
            // تحديث بيانات الوالدين إذا تم تحديدهما
            if (newPerson.fatherId && newPerson.fatherId !== '0') {
                const father = getPersonById(newPerson.fatherId);
                if (father && !father.children.includes(newPerson.id)) {
                    father.children.push(newPerson.id);
                    father.updatedAt = new Date().toISOString();
                }
            }
            
            if (newPerson.motherId && newPerson.motherId !== '0') {
                const mother = getPersonById(newPerson.motherId);
                if (mother && !mother.children.includes(newPerson.id)) {
                    mother.children.push(newPerson.id);
                    mother.updatedAt = new Date().toISOString();
                }
            }
            
            // تحديث بيانات الزوج/الزوجة
            if (newPerson.spouseId && newPerson.spouseId !== '0') {
                const spouse = getPersonById(newPerson.spouseId);
                if (spouse) {
                    spouse.spouseId = newPerson.id;
                    spouse.updatedAt = new Date().toISOString();
                    
                    // إنشاء عائلة جديدة
                    const family = {
                        husbandId: newPerson.gender === 'ذكر' ? newPerson.id : spouse.id,
                        wifeId: newPerson.gender === 'انثى' ? newPerson.id : spouse.id,
                        children: [],
                        marriageDate: new Date().toISOString().split('T')[0]
                    };
                    
                    familyData.families.push(family);
                }
            }
            
            familyData.persons.push(newPerson);
            familyData.lastUpdate = new Date().toISOString();
            
            saveData();
            
            resolve({
                success: true,
                message: 'تم إضافة الفرد بنجاح',
                person: newPerson
            });
            
        } catch (error) {
            reject({
                success: false,
                message: 'حدث خطأ أثناء إضافة الفرد: ' + error.message
            });
        }
    });
}

// تحديث بيانات فرد
function updatePerson(id, updatedData) {
    return new Promise((resolve, reject) => {
        try {
            const index = familyData.persons.findIndex(person => person.id === id);
            
            if (index === -1) {
                reject({
                    success: false,
                    message: 'الفرد غير موجود'
                });
                return;
            }
            
            // حفظ العلاقات القديمة
            const oldPerson = { ...familyData.persons[index] };
            
            // تحديث البيانات
            familyData.persons[index] = {
                ...familyData.persons[index],
                ...updatedData,
                id: id, // الحفاظ على المعرف
                updatedAt: new Date().toISOString()
            };
            
            // تحديث العلاقات إذا تغيرت
            const newPerson = familyData.persons[index];
            
            // تحديث علاقة الأب
            if (oldPerson.fatherId !== newPerson.fatherId) {
                // إزالة من الأب القديم
                if (oldPerson.fatherId && oldPerson.fatherId !== '0') {
                    const oldFather = getPersonById(oldPerson.fatherId);
                    if (oldFather) {
                        oldFather.children = oldFather.children.filter(childId => childId !== id);
                        oldFather.updatedAt = new Date().toISOString();
                    }
                }
                
                // إضافة للأب الجديد
                if (newPerson.fatherId && newPerson.fatherId !== '0') {
                    const newFather = getPersonById(newPerson.fatherId);
                    if (newFather && !newFather.children.includes(id)) {
                        newFather.children.push(id);
                        newFather.updatedAt = new Date().toISOString();
                    }
                }
            }
            
            // تحديث علاقة الأم
            if (oldPerson.motherId !== newPerson.motherId) {
                // إزالة من الأم القديمة
                if (oldPerson.motherId && oldPerson.motherId !== '0') {
                    const oldMother = getPersonById(oldPerson.motherId);
                    if (oldMother) {
                        oldMother.children = oldMother.children.filter(childId => childId !== id);
                        oldMother.updatedAt = new Date().toISOString();
                    }
                }
                
                // إضافة للأم الجديدة
                if (newPerson.motherId && newPerson.motherId !== '0') {
                    const newMother = getPersonById(newPerson.motherId);
                    if (newMother && !newMother.children.includes(id)) {
                        newMother.children.push(id);
                        newMother.updatedAt = new Date().toISOString();
                    }
                }
            }
            
            familyData.lastUpdate = new Date().toISOString();
            saveData();
            
            resolve({
                success: true,
                message: 'تم تحديث بيانات الفرد بنجاح',
                person: newPerson
            });
            
        } catch (error) {
            reject({
                success: false,
                message: 'حدث خطأ أثناء تحديث الفرد: ' + error.message
            });
        }
    });
}

// حذف فرد
function deletePerson(id) {
    return new Promise((resolve, reject) => {
        try {
            const person = getPersonById(id);
            
            if (!person) {
                reject({
                    success: false,
                    message: 'الفرد غير موجود'
                });
                return;
            }
            
            // التحقق من وجود أبناء
            if (person.children && person.children.length > 0) {
                reject({
                    success: false,
                    message: 'لا يمكن حذف فرد لديه أبناء. يرجى نقل الأبناء أولاً.'
                });
                return;
            }
            
            // إزالة من قائمة أبناء الوالدين
            if (person.fatherId && person.fatherId !== '0') {
                const father = getPersonById(person.fatherId);
                if (father) {
                    father.children = father.children.filter(childId => childId !== id);
                    father.updatedAt = new Date().toISOString();
                }
            }
            
            if (person.motherId && person.motherId !== '0') {
                const mother = getPersonById(person.motherId);
                if (mother) {
                    mother.children = mother.children.filter(childId => childId !== id);
                    mother.updatedAt = new Date().toISOString();
                }
            }
            
            // إزالة علاقة الزواج
            if (person.spouseId && person.spouseId !== '0') {
                const spouse = getPersonById(person.spouseId);
                if (spouse) {
                    spouse.spouseId = '0';
                    spouse.updatedAt = new Date().toISOString();
                }
                
                // حذف العائلة
                familyData.families = familyData.families.filter(family => 
                    family.husbandId !== id && family.wifeId !== id
                );
            }
            
            // حذف الفرد
            familyData.persons = familyData.persons.filter(person => person.id !== id);
            familyData.lastUpdate = new Date().toISOString();
            saveData();
            
            resolve({
                success: true,
                message: 'تم حذف الفرد بنجاح'
            });
            
        } catch (error) {
            reject({
                success: false,
                message: 'حدث خطأ أثناء حذف الفرد: ' + error.message
            });
        }
    });
}

// البحث عن الأفراد
function searchPersons(keyword) {
    const searchTerm = keyword.toLowerCase().trim();
    
    if (!searchTerm) {
        return [];
    }
    
    return familyData.persons.filter(person => {
        return (
            person.fullName.toLowerCase().includes(searchTerm) ||
            person.birthPlace?.toLowerCase().includes(searchTerm) ||
            person.notes?.toLowerCase().includes(searchTerm) ||
            person.occupation?.toLowerCase().includes(searchTerm)
        );
    });
}

// الحصول على جميع الذكور
function getAllMales() {
    return familyData.persons.filter(person => person.gender === 'ذكر');
}

// الحصول على جميع الإناث
function getAllFemales() {
    return familyData.persons.filter(person => person.gender === 'انثى');
}

// الحصول على الأحياء
function getLivingPersons() {
    return familyData.persons.filter(person => person.isAlive);
}

// الحصول على المتوفين
function getDeceasedPersons() {
    return familyData.persons.filter(person => !person.isAlive || person.deathDate);
}

// الحصول على الأبناء
function getChildren(parentId) {
    const parent = getPersonById(parentId);
    if (!parent) return [];
    
    return parent.children.map(childId => getPersonById(childId)).filter(child => child);
}

// الحصول على الأحفاد
function getGrandchildren(grandparentId) {
    const grandparent = getPersonById(grandparentId);
    if (!grandparent) return [];
    
    const grandchildren = [];
    
    grandparent.children.forEach(childId => {
        const child = getPersonById(childId);
        if (child) {
            grandchildren.push(...getChildren(child.id));
        }
    });
    
    return grandchildren;
}

// الحصول على الأسلاف (الآباء والأجداد)
function getAncestors(personId, generations = 3) {
    const person = getPersonById(personId);
    if (!person || generations <= 0) return [];
    
    const ancestors = [];
    
    if (person.fatherId && person.fatherId !== '0') {
        const father = getPersonById(person.fatherId);
        if (father) {
            ancestors.push(father);
            ancestors.push(...getAncestors(father.id, generations - 1));
        }
    }
    
    if (person.motherId && person.motherId !== '0') {
        const mother = getPersonById(person.motherId);
        if (mother) {
            ancestors.push(mother);
            ancestors.push(...getAncestors(mother.id, generations - 1));
        }
    }
    
    return ancestors;
}

// الحصول على الإحصائيات
function getStatistics() {
    const totalPersons = familyData.persons.length;
    const males = getAllMales().length;
    const females = getAllFemales().length;
    const living = getLivingPersons().length;
    const deceased = getDeceasedPersons().length;
    
    // حساب متوسط العمر
    const ages = familyData.persons
        .filter(person => person.birthDate && person.isAlive)
        .map(person => {
            const birthDate = new Date(person.birthDate);
            const now = new Date();
            return now.getFullYear() - birthDate.getFullYear();
        });
    
    const averageAge = ages.length > 0 ? 
        Math.round(ages.reduce((a, b) => a + b, 0) / ages.length) : 0;
    
    // الأفراد حسب مكان الميلاد
    const birthPlaces = {};
    familyData.persons.forEach(person => {
        const place = person.birthPlace || 'غير محدد';
        birthPlaces[place] = (birthPlaces[place] || 0) + 1;
    });
    
    // الأفراد حسب العمر
    const ageGroups = {
        '0-18': 0,
        '19-35': 0,
        '36-50': 0,
        '51-65': 0,
        '66+': 0
    };
    
    familyData.persons.forEach(person => {
        if (person.birthDate) {
            const birthDate = new Date(person.birthDate);
            const now = new Date();
            const age = now.getFullYear() - birthDate.getFullYear();
            
            if (age <= 18) ageGroups['0-18']++;
            else if (age <= 35) ageGroups['19-35']++;
            else if (age <= 50) ageGroups['36-50']++;
            else if (age <= 65) ageGroups['51-65']++;
            else ageGroups['66+']++;
        }
    });
    
    return {
        totalPersons,
        males,
        females,
        living,
        deceased,
        averageAge,
        birthPlaces,
        ageGroups,
        lastUpdate: familyData.lastUpdate
    };
}

// الحصول على شجرة العائلة
function getFamilyTree(rootId = null) {
    let rootPerson;
    
    if (rootId) {
        rootPerson = getPersonById(rootId);
    } else {
        // البحث عن الجد المؤسس (الشخص الذي ليس له أب)
        rootPerson = familyData.persons.find(person => 
            !person.fatherId || person.fatherId === '0'
        ) || familyData.persons[0];
    }
    
    if (!rootPerson) return null;
    
    function buildTree(person, depth = 0) {
        const node = {
            person,
            depth,
            children: []
        };
        
        if (person.children && person.children.length > 0) {
            person.children.forEach(childId => {
                const child = getPersonById(childId);
                if (child) {
                    node.children.push(buildTree(child, depth + 1));
                }
            });
        }
        
        return node;
    }
    
    return buildTree(rootPerson);
}

// تصدير البيانات
function exportData(format = 'json') {
    const data = {
        familyData,
        exportDate: new Date().toISOString(),
        version: '2.0.0'
    };
    
    switch (format) {
        case 'json':
            return JSON.stringify(data, null, 2);
            
        case 'csv':
            // تحويل إلى CSV
            const headers = ['الاسم', 'الجنس', 'مكان الميلاد', 'تاريخ الميلاد', 'تاريخ الوفاة', 'الأب', 'الأم', 'الزوج/الزوجة'];
            const rows = familyData.persons.map(person => [
                person.fullName,
                person.gender,
                person.birthPlace || '',
                person.birthDate || '',
                person.deathDate || '',
                person.fatherId ? getPersonById(person.fatherId)?.fullName || '' : '',
                person.motherId ? getPersonById(person.motherId)?.fullName || '' : '',
                person.spouseId ? getPersonById(person.spouseId)?.fullName || '' : ''
            ]);
            
            const csvContent = [
                headers.join(','),
                ...rows.map(row => row.join(','))
            ].join('\n');
            
            return csvContent;
            
        default:
            return data;
    }
}

// استيراد البيانات
function importData(data, merge = false) {
    return new Promise((resolve, reject) => {
        try {
            let importedData;
            
            if (typeof data === 'string') {
                importedData = JSON.parse(data);
            } else {
                importedData = data;
            }
            
            // التحقق من صحة البيانات
            if (!importedData.familyData || !Array.isArray(importedData.familyData.persons)) {
                throw new Error('بيانات غير صالحة');
            }
            
            if (merge) {
                // دمج البيانات
                importedData.familyData.persons.forEach(newPerson => {
                    const existingIndex = familyData.persons.findIndex(p => p.id === newPerson.id);
                    if (existingIndex === -1) {
                        familyData.persons.push(newPerson);
                    }
                });
                
                importedData.familyData.families.forEach(newFamily => {
                    const existingIndex = familyData.families.findIndex(f => 
                        f.husbandId === newFamily.husbandId && f.wifeId === newFamily.wifeId
                    );
                    if (existingIndex === -1) {
                        familyData.families.push(newFamily);
                    }
                });
            } else {
                // استبدال البيانات
                familyData = importedData.familyData;
            }
            
            familyData.lastUpdate = new Date().toISOString();
            saveData();
            
            resolve({
                success: true,
                message: 'تم استيراد البيانات بنجاح',
                count: importedData.familyData.persons.length
            });
            
        } catch (error) {
            reject({
                success: false,
                message: 'حدث خطأ أثناء استيراد البيانات: ' + error.message
            });
        }
    });
}

// تصدير الوظائف
window.familyData = {
    initFamilyData,
    getAllPersons,
    getPersonById,
    addPerson,
    updatePerson,
    deletePerson,
    searchPersons,
    getAllMales,
    getAllFemales,
    getLivingPersons,
    getDeceasedPersons,
    getChildren,
    getGrandchildren,
    getAncestors,
    getStatistics,
    getFamilyTree,
    exportData,
    importData,
    saveData
};

// التهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initFamilyData);