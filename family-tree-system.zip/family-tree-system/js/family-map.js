/**
 * الخريطة العائلية
 * @file family-map.js
 * @description عرض خريطة جغرافية لأماكن العائلة
 */

class FamilyMap {
    static init() {
        this.container = document.querySelector('#map-container');
        if (!this.container) return;

        this.user = AuthService.getCurrentUser();
        if (!this.user) return;

        this.familyData = FamilyDataService.loadFamilyData(this.user.id);
        this.map = null;
        this.markers = [];
        this.clusterGroup = null;

        this.initMap();
        this.loadFamilyLocations();
        this.setupControls();
    }

    static initMap() {
        // استخدام OpenStreetMap
        this.map = L.map('map-container').setView([24.7136, 46.6753], 5); // مركز على السعودية

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 18
        }).addTo(this.map);

        // إضافة التحكم بمقياس الرسم
        L.control.scale().addTo(this.map);

        // تجميع العلامات
        this.clusterGroup = L.markerClusterGroup({
            showCoverageOnHover: false,
            maxClusterRadius: 50
        });
        this.map.addLayer(this.clusterGroup);
    }

    static loadFamilyLocations() {
        if (this.familyData.members.length === 0) {
            this.showEmptyState();
            return;
        }

        // تصفية الأعضاء الذين لديهم أماكن ميلاد
        const membersWithLocations = this.familyData.members.filter(member => 
            member.birthPlace && member.birthPlace.trim() !== ''
        );

        if (membersWithLocations.length === 0) {
            this.showNoLocationsState();
            return;
        }

        // جلب إحداثيات الأماكن
        this.geocodeLocations(membersWithLocations);
    }

    static async geocodeLocations(members) {
        const geocodedMembers = [];
        
        // لتجنب تجاوز حد طلبات API، نجمع الأماكن الفريدة أولاً
        const uniquePlaces = [...new Set(members.map(m => m.birthPlace))];
        
        for (const place of uniquePlaces) {
            try {
                const coordinates = await this.geocodePlace(place);
                if (coordinates) {
                    const membersInPlace = members.filter(m => m.birthPlace === place);
                    geocodedMembers.push({
                        place: place,
                        coordinates: coordinates,
                        members: membersInPlace
                    });
                }
            } catch (error) {
                console.error(`خطأ في تحديد موقع: ${place}`, error);
            }
        }

        this.displayMarkers(geocodedMembers);
        this.updateMapStats(geocodedMembers);
    }

    static async geocodePlace(place) {
        // استخدام Nominatim (OpenStreetMap geocoding)
        const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(place)}&limit=1`;
        
        try {
            const response = await fetch(url);
            const data = await response.json();
            
            if (data && data.length > 0) {
                return {
                    lat: parseFloat(data[0].lat),
                    lng: parseFloat(data[0].lon)
                };
            }
        } catch (error) {
            console.error('خطأ في جلب الإحداثيات:', error);
        }
        
        return null;
    }

    static displayMarkers(geocodedMembers) {
        // مسح العلامات السابقة
        this.clusterGroup.clearLayers();
        this.markers = [];

        geocodedMembers.forEach(location => {
            const marker = this.createMarker(location);
            if (marker) {
                this.markers.push(marker);
                this.clusterGroup.addLayer(marker);
            }
        });

        // تكبير الخريطة لتناسب جميع العلامات
        if (this.markers.length > 0) {
            const group = L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.1));
        }
    }

    static createMarker(location) {
        if (!location.coordinates) return null;

        const icon = L.divIcon({
            className: 'family-marker',
            html: `
                <div class="marker-content">
                    <div class="marker-icon">📍</div>
                    <div class="marker-count">${location.members.length}</div>
                </div>
            `,
            iconSize: [40, 40],
            iconAnchor: [20, 40]
        });

        const marker = L.marker([location.coordinates.lat, location.coordinates.lng], { icon: icon });
        
        // محتوى المنبثق
        const popupContent = this.createPopupContent(location);
        marker.bindPopup(popupContent, {
            maxWidth: 300,
            minWidth: 250
        });

        return marker;
    }

    static createPopupContent(location) {
        const membersList = location.members.map(member => `
            <div class="map-member-item" data-member-id="${member.id}">
                <div class="member-icon">${member.gender === 'female' ? '👩' : '👨'}</div>
                <div class="member-info">
                    <div class="member-name">${member.firstName} ${member.lastName}</div>
                    ${member.birthDate ? `<div class="member-birthdate">${member.birthDate}</div>` : ''}
                </div>
            </div>
        `).join('');

        return `
            <div class="map-popup">
                <h4>${location.place}</h4>
                <div class="popup-stats">
                    <span>عدد الأعضاء: ${location.members.length}</span>
                </div>
                <div class="members-list">
                    ${membersList}
                </div>
                <div class="popup-actions">
                    <button class="btn-view-details" onclick="FamilyMap.viewLocationDetails('${location.place}')">
                        عرض التفاصيل
                    </button>
                </div>
            </div>
        `;
    }

    static updateMapStats(locations) {
        const statsContainer = document.querySelector('#map-stats');
        if (!statsContainer) return;

        const totalLocations = locations.length;
        const totalMembers = locations.reduce((sum, loc) => sum + loc.members.length, 0);
        const uniqueCities = new Set(locations.map(loc => {
            const parts = loc.place.split(',').map(p => p.trim());
            return parts.length > 0 ? parts[0] : loc.place;
        }));

        statsContainer.innerHTML = `
            <div class="map-statistics">
                <h4>إحصائيات الخريطة</h4>
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-label">عدد الأماكن:</span>
                        <span class="stat-value">${totalLocations}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">عدد الأعضاء:</span>
                        <span class="stat-value">${totalMembers}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">عدد المدن:</span>
                        <span class="stat-value">${uniqueCities.size}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">الأكثر عدداً:</span>
                        <span class="stat-value">
                            ${this.getMostPopulatedLocation(locations)}
                        </span>
                    </div>
                </div>
            </div>
        `;
    }

    static getMostPopulatedLocation(locations) {
        if (locations.length === 0) return 'لا توجد بيانات';
        
        const mostPopulated = locations.reduce((max, loc) => 
            loc.members.length > max.members.length ? loc : max
        );
        
        return `${mostPopulated.place} (${mostPopulated.members.length})`;
    }

    static viewLocationDetails(place) {
        const membersInPlace = this.familyData.members.filter(m => m.birthPlace === place);
        
        const detailsHtml = `
            <div class="location-details-modal">
                <div class="modal-header">
                    <h3>${place}</h3>
                    <button class="btn-close-modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="location-members">
                        ${membersInPlace.map(member => `
                            <div class="member-card" data-member-id="${member.id}">
                                <div class="member-avatar">
                                    ${member.gender === 'female' ? '👩' : '👨'}
                                </div>
                                <div class="member-details">
                                    <h4>${member.firstName} ${member.lastName}</h4>
                                    <div class="member-info">
                                        ${member.birthDate ? `<div>الميلاد: ${member.birthDate}</div>` : ''}
                                        ${member.generation ? `<div>الجيل: ${member.generation}</div>` : ''}
                                    </div>
                                </div>
                                <button class="btn-view-member" data-member-id="${member.id}">
                                    عرض الملف
                                </button>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;

        this.showModal(detailsHtml);
        
        // إضافة مستمعي الأحداث
        document.querySelectorAll('.btn-view-member').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const memberId = e.target.getAttribute('data-member-id');
                this.viewMemberOnMap(memberId);
            });
        });
    }

    static viewMemberOnMap(memberId) {
        const member = this.familyData.members.find(m => m.id === memberId);
        if (!member || !member.birthPlace) return;

        // العثور على العلامة المناسبة وفتحها
        this.markers.forEach(marker => {
            const popup = marker.getPopup();
            if (popup && popup.getContent().includes(`data-member-id="${memberId}"`)) {
                marker.openPopup();
                this.map.setView(marker.getLatLng(), 12);
            }
        });
    }

    static setupControls() {
        const controls = document.querySelector('#map-controls');
        if (!controls) return;

        // تصفية حسب الجيل
        const generationFilter = controls.querySelector('#map-generation-filter');
        if (generationFilter) {
            generationFilter.addEventListener('change', (e) => {
                this.filterByGeneration(e.target.value);
            });
        }

        // بحث المكان
        const searchInput = controls.querySelector('#map-search');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchLocations(e.target.value);
            });
        }

        // تصدير الخريطة
        const exportBtn = controls.querySelector('#export-map');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportMap();
            });
        }
    }

    static filterByGeneration(generation) {
        const allMembers = this.familyData.members;
        let filteredMembers;
        
        if (generation === 'all') {
            filteredMembers = allMembers;
        } else {
            filteredMembers = allMembers.filter(member => member.generation == generation);
        }

        const membersWithLocations = filteredMembers.filter(m => m.birthPlace);
        this.geocodeLocations(membersWithLocations);
    }

    static searchLocations(searchTerm) {
        if (!searchTerm.trim()) {
            this.loadFamilyLocations();
            return;
        }

        const filteredMembers = this.familyData.members.filter(member => {
            const searchableText = [
                member.birthPlace,
                member.firstName,
                member.lastName
            ].filter(Boolean).join(' ').toLowerCase();
            
            return searchableText.includes(searchTerm.toLowerCase());
        });

        this.geocodeLocations(filteredMembers.filter(m => m.birthPlace));
    }

    static exportMap() {
        // إنشاء صورة للخريطة
        this.map.once('rendercomplete', () => {
            const mapCanvas = document.createElement('canvas');
            const size = this.map.getSize();
            
            mapCanvas.width = size.x;
            mapCanvas.height = size.y;
            
            const context = mapCanvas.getContext('2d');
            
            // يمكن إضافة مزيد من التفاصيل هنا لتصدير الصورة
            // في بيئة حقيقية، يمكن استخدام مكتبة مثل html2canvas
            
            const link = document.createElement('a');
            link.download = `family-map-${new Date().toISOString().split('T')[0]}.png`;
            link.href = mapCanvas.toDataURL();
            link.click();
        });
        
        this.map.fire('rendercomplete');
    }

    static showModal(content) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = content;
        
        document.body.appendChild(modal);
        
        modal.querySelector('.btn-close-modal').addEventListener('click', () => {
            modal.remove();
        });
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    static showEmptyState() {
        this.container.innerHTML = `
            <div class="map-empty-state">
                <div class="empty-icon">🗺️</div>
                <h3>لا توجد بيانات لعرضها</h3>
                <p>أضف أعضاء العائلة أولاً لعرض الخريطة</p>
                <button class="btn btn-primary" data-nav="dashboard">
                    إضافة أعضاء
                </button>
            </div>
        `;
    }

    static showNoLocationsState() {
        this.container.innerHTML = `
            <div class="map-empty-state">
                <div class="empty-icon">📍</div>
                <h3>لا توجد أماكن محددة</h3>
                <p>أضف أماكن الميلاد للأعضاء لعرضهم على الخريطة</p>
                <button class="btn btn-primary" data-nav="dashboard">
                    تحديث البيانات
                </button>
            </div>
        `;
    }

    static refresh() {
        this.familyData = FamilyDataService.loadFamilyData(this.user.id);
        this.loadFamilyLocations();
    }
}

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    if (window.App && App.currentView === 'map') {
        FamilyMap.init();
    }
});