/**
 * التطبيق الرئيسي لنظام شجرة العائلة
 * @file app.js
 * @description إدارة التطبيق الرئيسي والتنقل بين الصفحات
 */

class FamilyTreeApp {
    constructor() {
        this.currentUser = null;
        this.currentView = 'login';
        this.familyData = null;
        this.init();
    }

    init() {
        this.checkAuthState();
        this.setupEventListeners();
        this.loadInitialData();
    }

    checkAuthState() {
        const token = localStorage.getItem('family-tree-token');
        if (token && AuthService.validateToken(token)) {
            this.currentUser = AuthService.getCurrentUser();
            this.navigateTo('dashboard');
        } else {
            this.navigateTo('login');
        }
    }

    setupEventListeners() {
        // التنقل العام
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-nav]')) {
                e.preventDefault();
                const view = e.target.getAttribute('data-nav');
                this.navigateTo(view);
            }

            if (e.target.matches('[data-logout]')) {
                this.logout();
            }
        });

        // إغلاق الرسائل
        document.addEventListener('click', (e) => {
            if (e.target.matches('.close-message')) {
                e.target.closest('.message').remove();
            }
        });

        // الضغط على زر الإدخال
        document.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.target.matches('input[type="text"], input[type="password"]')) {
                e.target.closest('form')?.querySelector('button[type="submit"]')?.click();
            }
        });
    }

    loadInitialData() {
        // تحميل البيانات الأولية إذا كان المستخدم مسجل الدخول
        if (this.currentUser) {
            this.familyData = FamilyDataService.loadFamilyData(this.currentUser.id);
        }
    }

    navigateTo(view) {
        this.currentView = view;
        this.updateView();
        
        // تشغيل الوظائف الخاصة بكل صفحة
        switch(view) {
            case 'dashboard':
                DashboardView.init();
                break;
            case 'tree':
                TreeView.init();
                break;
            case 'map':
                FamilyMap.init();
                break;
            case 'export':
                ExportService.init();
                break;
        }
    }

    updateView() {
        // إخفاء جميع الأقسام
        document.querySelectorAll('.page-section').forEach(section => {
            section.classList.add('hidden');
        });

        // إظهار القسم المطلوب
        const targetSection = document.querySelector(`#${this.currentView}-section`);
        if (targetSection) {
            targetSection.classList.remove('hidden');
        }

        // تحديث القائمة النشطة
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-nav') === this.currentView) {
                link.classList.add('active');
            }
        });
    }

    logout() {
        AuthService.logout();
        this.currentUser = null;
        this.navigateTo('login');
        this.showMessage('تم تسجيل الخروج بنجاح', 'success');
    }

    showMessage(text, type = 'info') {
        const message = document.createElement('div');
        message.className = `message message-${type}`;
        message.innerHTML = `
            <span>${text}</span>
            <button class="close-message">&times;</button>
        `;
        
        const container = document.querySelector('.messages-container') || document.body;
        container.prepend(message);
        
        // إزالة الرسالة تلقائياً بعد 5 ثوانٍ
        setTimeout(() => {
            if (message.parentNode) {
                message.remove();
            }
        }, 5000);
    }

    updateUserData(userData) {
        this.currentUser = { ...this.currentUser, ...userData };
        localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
    }
}

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.App = new FamilyTreeApp();
});