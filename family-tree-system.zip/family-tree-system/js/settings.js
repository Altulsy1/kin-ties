/**
 * إدارة إعدادات النظام
 */

class SystemSettings {
    constructor() {
        this.settings = this.loadSettings();
        this.init();
    }
    
    // تحميل الإعدادات
    loadSettings() {
        const defaultSettings = {
            general: {
                siteTitle: 'شجرة عائلة محمد عبدالرحمن',
                language: 'ar',
                theme: 'light',
                timezone: 'Asia/Riyadh',
                dateFormat: 'dd/MM/yyyy',
                itemsPerPage: 20
            },
            family: {
                allowMultipleMarriages: true,
                allowSameGenderMarriage: false,
                maxChildrenPerFamily: 20,
                autoCalculateAge: true,
                showLivingOnly: false
            },
            backup: {
                autoBackup: true,
                backupInterval: 24, // ساعات
                maxBackups: 10,
                backupLocation: 'local'
            },
            privacy: {
                showFullInfo: true,
                requireLogin: true,
                hideDeceased: false,
                encryptData: false
            },
            notifications: {
                emailNotifications: false,
                emailAddress: '',
                birthdayReminders: true,
                anniversaryReminders: true,
                systemAlerts: true
            },
            display: {
                showAvatars: true,
                showAge: true,
                showOccupation: true,
                treeLayout: 'vertical',
                animationSpeed: 'normal'
            },
            export: {
                defaultFormat: 'pdf',
                includePhotos: true,
                includeNotes: true,
                compressionLevel: 'medium'
            }
        };
        
        const savedSettings = localStorage.getItem('systemSettings');
        if (savedSettings) {
            try {
                return { ...defaultSettings, ...JSON.parse(savedSettings) };
            } catch (error) {
                console.error('خطأ في تحميل الإعدادات:', error);
                return defaultSettings;
            }
        }
        
        return defaultSettings;
    }
    
    // حفظ الإعدادات
    saveSettings() {
        try {
            localStorage.setItem('systemSettings', JSON.stringify(this.settings));
            return true;
        } catch (error) {
            console.error('خطأ في حفظ الإعدادات:', error);
            return false;
        }
    }
    
    // التهيئة
    init() {
        this.applySettings();
    }
    
    // تطبيق الإعدادات
    applySettings() {
        // تطبيق إعدادات المظهر
        this.applyTheme();
        
        // تطبيق إعدادات اللغة
        this.applyLanguage();
        
        // تطبيق إعدادات العرض
        this.applyDisplaySettings();
    }
    
    // تطبيق الثيم
    applyTheme() {
        const theme = this.settings.general.theme;
        document.body.classList.remove('theme-light', 'theme-dark');
        document.body.classList.add(`theme-${theme}`);
        
        // إضافة أنماط الثيم
        if (!document.getElementById('theme-styles')) {
            const style = document.createElement('style');
            style.id = 'theme-styles';
            document.head.appendChild(style);
        }
        
        const themeStyles = document.getElementById('theme-styles');
        if (theme === 'dark') {
            themeStyles.textContent = `
                body.theme-dark {
                    --bg-primary: #1a1a2e;
                    --bg-secondary: #16213e;
                    --text-primary: #ffffff;
                    --text-secondary: #b0b0b0;
                    --border-color: #2d3748;
                }
            `;
        } else {
            themeStyles.textContent = `
                body.theme-light {
                    --bg-primary: #ffffff;
                    --bg-secondary: #f8f9fa;
                    --text-primary: #2c3e50;
                    --text-secondary: #7f8c8d;
                    --border-color: #dee2e6;
                }
            `;
        }
    }
    
    // تطبيق اللغة
    applyLanguage() {
        const lang = this.settings.general.language;
        document.documentElement.lang = lang;
        
        // يمكن إضافة ترجمة ديناميكية هنا
        if (lang === 'en') {
            // تطبيق النصوص الإنجليزية
            this.applyEnglishTexts();
        }
    }
    
    // تطبيق النصوص الإنجليزية
    applyEnglishTexts() {
        // هذا مثال مبسط، في التطبيق الحقيقي يجب استخدام نظام ترجمة
        const translations = {
            'شجرة عائلة محمد عبدالرحمن': 'Mohammed Abdulrahman Family Tree',
            'لوحة التحكم': 'Dashboard',
            'إدارة الأفراد': 'Manage Persons',
            'إضافة فرد جديد': 'Add New Person',
            'عرض الشجرة': 'View Tree',
            'الخريطة العائلية': 'Family Map',
            'التقارير والإحصاءات': 'Reports & Statistics',
            'كتاب العائلة': 'Family Book',
            'النسخ الاحتياطي': 'Backup',
            'الإعدادات': 'Settings'
        };
        
        Object.keys(translations).forEach(key => {
            document.querySelectorAll(`:contains("${key}")`).forEach(element => {
                if (element.textContent === key) {
                    element.textContent = translations[key];
                }
            });
        });
    }
    
    // تطبيق إعدادات العرض
    applyDisplaySettings() {
        const display = this.settings.display;
        
        // تطبيق سرعة الرسوم المتحركة
        document.documentElement.style.setProperty('--animation-speed', 
            display.animationSpeed === 'fast' ? '0.2s' : 
            display.animationSpeed === 'slow' ? '0.5s' : '0.3s'
        );
        
        // إظهار/إخفاء الصور الرمزية
        const avatars = document.querySelectorAll('.person-avatar');
        avatars.forEach(avatar => {
            avatar.style.display = display.showAvatars ? 'flex' : 'none';
        });
        
        // إظهار/إخفاء الأعمار
        const ages = document.querySelectorAll('.person-age');
        ages.forEach(age => {
            age.style.display = display.showAge ? 'inline' : 'none';
        });
    }
    
    // تحديث إعداد
    updateSetting(category, key, value) {
        if (this.settings[category] && this.settings[category][key] !== undefined) {
            this.settings[category][key] = value;
            
            // حفظ التغييرات
            this.saveSettings();
            
            // تطبيق التغييرات الفورية
            this.applySettingChange(category, key, value);
            
            return true;
        }
        return false;
    }
    
    // تطبيق تغيير إعداد معين
    applySettingChange(category, key, value) {
        switch (category) {
            case 'general':
                if (key === 'theme') {
                    this.applyTheme();
                } else if (key === 'language') {
                    this.applyLanguage();
                }
                break;
                
            case 'display':
                this.applyDisplaySettings();
                break;
                
            case 'family':
                // إعادة تحميل بيانات العائلة
                window.familyData.initFamilyData();
                break;
                
            case 'backup':
                // تحديث إعدادات النسخ الاحتياطي
                if (window.BackupSystem) {
                    const backupSystem = new BackupSystem();
                    if (key === 'autoBackup') {
                        backupSystem.toggleAutoBackup(value);
                    }
                }
                break;
        }
    }
    
    // إعادة تعيين الإعدادات
    resetSettings() {
        const defaultSettings = {
            general: {
                siteTitle: 'شجرة عائلة محمد عبدالرحمن',
                language: 'ar',
                theme: 'light',
                timezone: 'Asia/Riyadh',
                dateFormat: 'dd/MM/yyyy',
                itemsPerPage: 20
            },
            family: {
                allowMultipleMarriages: true,
                allowSameGenderMarriage: false,
                maxChildrenPerFamily: 20,
                autoCalculateAge: true,
                showLivingOnly: false
            },
            backup: {
                autoBackup: true,
                backupInterval: 24,
                maxBackups: 10,
                backupLocation: 'local'
            },
            privacy: {
                showFullInfo: true,
                requireLogin: true,
                hideDeceased: false,
                encryptData: false
            },
            notifications: {
                emailNotifications: false,
                emailAddress: '',
                birthdayReminders: true,
                anniversaryReminders: true,
                systemAlerts: true
            },
            display: {
                showAvatars: true,
                showAge: true,
                showOccupation: true,
                treeLayout: 'vertical',
                animationSpeed: 'normal'
            },
            export: {
                defaultFormat: 'pdf',
                includePhotos: true,
                includeNotes: true,
                compressionLevel: 'medium'
            }
        };
        
        this.settings = defaultSettings;
        this.saveSettings();
        this.applySettings();
        
        window.utils.showNotification('تم إعادة تعيين الإعدادات إلى الافتراضية', 'success');
    }
    
    // تصدير الإعدادات
    exportSettings() {
        try {
            const dataStr = JSON.stringify(this.settings, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            const url = URL.createObjectURL(dataBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `system_settings_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            window.utils.showNotification('تم تصدير الإعدادات بنجاح', 'success');
            
        } catch (error) {
            window.utils.showNotification('حدث خطأ أثناء تصدير الإعدادات', 'error');
            console.error('Export Settings Error:', error);
        }
    }
    
    // استيراد الإعدادات
    importSettings(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (event) => {
                try {
                    const importedSettings = JSON.parse(event.target.result);
                    
                    // التحقق من صحة البيانات
                    if (!this.validateSettings(importedSettings)) {
                        throw new Error('ملف الإعدادات غير صالح');
                    }
                    
                    // دمج الإعدادات
                    this.settings = { ...this.settings, ...importedSettings };
                    this.saveSettings();
                    this.applySettings();
                    
                    window.utils.showNotification('تم استيراد الإعدادات بنجاح', 'success');
                    resolve({ success: true });
                    
                } catch (error) {
                    window.utils.showNotification('ملف الإعدادات غير صالح', 'error');
                    console.error('Import Settings Error:', error);
                    reject({ success: false, message: error.message });
                }
            };
            
            reader.onerror = () => {
                reject({ success: false, message: 'خطأ في قراءة الملف' });
            };
            
            reader.readAsText(file);
        });
    }
    
    // التحقق من صحة الإعدادات
    validateSettings(settings) {
        const requiredCategories = ['general', 'family', 'privacy', 'display'];
        
        for (const category of requiredCategories) {
            if (!settings[category]) {
                return false;
            }
        }
        
        return true;
    }
    
    // الحصول على قيمة إعداد
    getSetting(category, key) {
        return this.settings[category]?.[key];
    }
    
    // الحصول على جميع الإعدادات
    getAllSettings() {
        return this.settings;
    }
    
    // تحديث واجهة الإعدادات
    updateSettingsUI() {
        // تحديث حقول الإدخال
        for (const category in this.settings) {
            for (const key in this.settings[category]) {
                const inputId = `setting_${category}_${key}`;
                const input = document.getElementById(inputId);
                
                if (input) {
                    const value = this.settings[category][key];
                    
                    if (input.type === 'checkbox') {
                        input.checked = value;
                    } else if (input.type === 'range') {
                        input.value = value;
                        const valueDisplay = document.getElementById(`${inputId}_value`);
                        if (valueDisplay) {
                            valueDisplay.textContent = value;
                        }
                    } else {
                        input.value = value;
                    }
                }
            }
        }
        
        // تحديث معاينة العنوان
        const siteTitlePreview = document.getElementById('siteTitlePreview');
        if (siteTitlePreview) {
            siteTitlePreview.textContent = this.settings.general.siteTitle;
        }
        
        // تحديث معاينة الثيم
        const themePreview = document.getElementById('themePreview');
        if (themePreview) {
            themePreview.className = `theme-preview ${this.settings.general.theme}`;
        }
    }
    
    // حفظ الإعدادات من الواجهة
    saveSettingsFromUI() {
        const settingsForm = document.getElementById('settingsForm');
        if (!settingsForm) return;
        
        const formData = new FormData(settingsForm);
        
        // تحديث الإعدادات من النموذج
        for (const [name, value] of formData.entries()) {
            if (name.startsWith('setting_')) {
                const parts = name.replace('setting_', '').split('_');
                const category = parts[0];
                const key = parts.slice(1).join('_');
                
                let processedValue = value;
                
                // معالجة أنواع البيانات المختلفة
                const input = settingsForm.querySelector(`[name="${name}"]`);
                if (input) {
                    if (input.type === 'checkbox') {
                        processedValue = input.checked;
                    } else if (input.type === 'number') {
                        processedValue = parseInt(value);
                    } else if (input.type === 'range') {
                        processedValue = parseInt(value);
                    }
                }
                
                this.updateSetting(category, key, processedValue);
            }
        }
        
        window.utils.showNotification('تم حفظ الإعدادات بنجاح', 'success');
        return true;
    }
}

// التهيئة
function initSettings() {
    const systemSettings = new SystemSettings();
    
    // تحديث واجهة الإعدادات عند فتح الصفحة
    setTimeout(() => {
        systemSettings.updateSettingsUI();
    }, 500);
    
    // حفظ الإعدادات
    const saveSettingsBtn = document.getElementById('saveSettingsBtn');
    if (saveSettingsBtn) {
        saveSettingsBtn.addEventListener('click', (e) => {
            e.preventDefault();
            systemSettings.saveSettingsFromUI();
        });
    }
    
    // إعادة تعيين الإعدادات
    const resetSettingsBtn = document.getElementById('resetSettingsBtn');
    if (resetSettingsBtn) {
        resetSettingsBtn.addEventListener('click', () => {
            window.utils.showConfirm(
                'هل أنت متأكد من إعادة تعيين جميع الإعدادات إلى القيم الافتراضية؟',
                'تأكيد إعادة التعيين'
            ).then(confirmed => {
                if (confirmed) {
                    systemSettings.resetSettings();
                    systemSettings.updateSettingsUI();
                }
            });
        });
    }
    
    // تصدير الإعدادات
    const exportSettingsBtn = document.getElementById('exportSettingsBtn');
    if (exportSettingsBtn) {
        exportSettingsBtn.addEventListener('click', () => {
            systemSettings.exportSettings();
        });
    }
    
    // استيراد الإعدادات
    const importSettingsBtn = document.getElementById('importSettingsBtn');
    if (importSettingsBtn) {
        importSettingsBtn.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            
            input.onchange = async (e) => {
                const file = e.target.files[0];
                if (file) {
                    await systemSettings.importSettings(file);
                    systemSettings.updateSettingsUI();
                }
            };
            
            input.click();
        });
    }
    
    // تحديث معاينة العنوان
    const siteTitleInput = document.getElementById('setting_general_siteTitle');
    if (siteTitleInput) {
        siteTitleInput.addEventListener('input', (e) => {
            const preview = document.getElementById('siteTitlePreview');
            if (preview) {
                preview.textContent = e.target.value || 'شجرة العائلة';
            }
        });
    }
    
    // تحديث معاينة الثيم
    const themeSelect = document.getElementById('setting_general_theme');
    if (themeSelect) {
        themeSelect.addEventListener('change', (e) => {
            const preview = document.getElementById('themePreview');
            if (preview) {
                preview.className = `theme-preview ${e.target.value}`;
            }
        });
    }
    
    // تحديث قيم الـ Range
    document.querySelectorAll('input[type="range"]').forEach(input => {
        input.addEventListener('input', (e) => {
            const valueDisplay = document.getElementById(`${e.target.id}_value`);
            if (valueDisplay) {
                valueDisplay.textContent = e.target.value;
            }
        });
    });
    
    // اختبار إشعارات البريد
    const testEmailBtn = document.getElementById('testEmailBtn');
    if (testEmailBtn) {
        testEmailBtn.addEventListener('click', () => {
            const email = systemSettings.getSetting('notifications', 'emailAddress');
            if (!email) {
                window.utils.showNotification('يرجى إدخال بريد إلكتروني أولاً', 'warning');
                return;
            }
            
            window.utils.showNotification(`سيتم إرسال بريد اختباري إلى: ${email}`, 'info');
            // في التطبيق الحقيقي، هنا سيتم إرسال بريد اختباري
        });
    }
    
    // اختبار النسخ الاحتياطي
    const testBackupBtn = document.getElementById('testBackupBtn');
    if (testBackupBtn) {
        testBackupBtn.addEventListener('click', () => {
            if (window.BackupSystem) {
                const backupSystem = new BackupSystem();
                backupSystem.createManualBackup('اختباري');
            }
        });
    }
    
    // تنظيف البيانات المؤقتة
    const clearCacheBtn = document.getElementById('clearCacheBtn');
    if (clearCacheBtn) {
        clearCacheBtn.addEventListener('click', () => {
            window.utils.showConfirm(
                'هل تريد حذف البيانات المؤقتة؟ هذا سيسرع النظام ولكن قد يحذف بعض البيانات غير المحفوظة.',
                'تنظيف الذاكرة المؤقتة'
            ).then(confirmed => {
                if (confirmed) {
                    // حذف البيانات المؤقتة
                    const tempData = ['tempFamilyData', 'tempSettings', 'tempBackups'];
                    tempData.forEach(key => {
                        sessionStorage.removeItem(key);
                    });
                    
                    window.utils.showNotification('تم تنظيف الذاكرة المؤقتة بنجاح', 'success');
                }
            });
        });
    }
    
    // معلومات النظام
    const systemInfoBtn = document.getElementById('systemInfoBtn');
    if (systemInfoBtn) {
        systemInfoBtn.addEventListener('click', () => {
            const info = `
                <h3>معلومات النظام</h3>
                <div class="system-info">
                    <p><strong>الإصدار:</strong> 2.0.0</p>
                    <p><strong>آخر تحديث:</strong> ${new Date().toLocaleDateString('ar-SA')}</p>
                    <p><strong>عدد الأفراد:</strong> ${window.familyData.getAllPersons().length}</p>
                    <p><strong>المساحة المستخدمة:</strong> ${this.calculateStorageUsage()} KB</p>
                    <p><strong>المتصفح:</strong> ${navigator.userAgent.split(') ')[0].split('(')[1]}</p>
                    <p><strong>دعم localStorage:</strong> ${typeof localStorage !== 'undefined' ? 'نعم' : 'لا'}</p>
                </div>
            `;
            
            window.utils.showNotification(info, 'info', 10000);
        });
    }
    
    // حساب استخدام التخزين
    function calculateStorageUsage() {
        let total = 0;
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            const value = localStorage.getItem(key);
            total += key.length + value.length;
        }
        return (total / 1024).toFixed(2);
    }
}

// تصدير الفئة
window.SystemSettings = SystemSettings;

// التهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initSettings);