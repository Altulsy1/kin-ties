/**
 * عرض شجرة العائلة
 * @file tree-view.js
 * @description عرض شجرة العائلة التفاعلية
 */

class TreeView {
    static init() {
        this.container = document.querySelector('#tree-container');
        if (!this.container) return;

        this.user = AuthService.getCurrentUser();
        if (!this.user) return;

        this.familyData = FamilyDataService.loadFamilyData(this.user.id);
        this.currentZoom = 1;
        this.panOffset = { x: 0, y: 0 };
        this.isPanning = false;
        this.startPan = { x: 0, y: 0 };

        this.renderTree();
        this.setupEventListeners();
        this.setupControls();
    }

    static renderTree() {
        if (this.familyData.members.length === 0) {
            this.container.innerHTML = `
                <div class="tree-empty-state">
                    <div class="empty-icon">🌳</div>
                    <h3>لا توجد بيانات لعرضها</h3>
                    <p>ابدأ بإضافة أعضاء العائلة لعرض الشجرة</p>
                    <button class="btn btn-primary" data-nav="dashboard">
                        إضافة أعضاء
                    </button>
                </div>
            `;
            return;
        }

        // تنظيف الحاوية
        this.container.innerHTML = '';

        // إنشاء عنصر SVG للشجرة
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('id', 'tree-svg');
        svg.setAttribute('width', '100%');
        svg.setAttribute('height', '100%');
        svg.style.transform = `scale(${this.currentZoom}) translate(${this.panOffset.x}px, ${this.panOffset.y}px)`;

        // إنشاء عنصر جروب للعناصر
        const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        g.setAttribute('id', 'tree-group');

        // تحديد الجذر (الأسلاف)
        const rootMembers = this.findRootMembers();
        
        if (rootMembers.length === 0) {
            this.container.innerHTML = '<div class="error">لا يمكن إنشاء الشجرة بدون أسلاف</div>';
            return;
        }

        // تنظيم الأعضاء حسب الأجيال
        const generations = this.organizeByGeneration();
        
        // حساب المواقع
        const positions = this.calculatePositions(generations);

        // رسم الروابط أولاً
        this.drawConnections(g, positions);

        // رسم الأعضاء
        this.drawMembers(g, positions);

        svg.appendChild(g);
        this.container.appendChild(svg);

        // إضافة معلومات الشجرة
        this.renderTreeInfo();
    }

    static findRootMembers() {
        return this.familyData.members.filter(member => {
            // الأعضاء الذين ليس لديهم آباء مسجلين
            if (!member.parents || member.parents.length === 0) {
                return true;
            }
            
            // أو آباؤهم غير موجودين في البيانات
            const existingParents = member.parents.filter(parentId => 
                this.familyData.members.some(m => m.id === parentId)
            );
            
            return existingParents.length === 0;
        });
    }

    static organizeByGeneration() {
        const generations = {};
        
        this.familyData.members.forEach(member => {
            const generation = member.generation || 1;
            if (!generations[generation]) {
                generations[generation] = [];
            }
            generations[generation].push(member);
        });

        return generations;
    }

    static calculatePositions(generations) {
        const positions = {};
        const generationGap = 200;
        const memberGap = 150;
        const startY = 100;
        
        const sortedGenerations = Object.keys(generations)
            .map(Number)
            .sort((a, b) => a - b);

        sortedGenerations.forEach((genNum, genIndex) => {
            const members = generations[genNum];
            const totalWidth = (members.length - 1) * memberGap;
            const startX = (window.innerWidth - totalWidth) / 2;
            
            members.forEach((member, memberIndex) => {
                positions[member.id] = {
                    x: startX + (memberIndex * memberGap),
                    y: startY + (genIndex * generationGap),
                    generation: genNum,
                    index: memberIndex
                };
            });
        });

        return positions;
    }

    static drawConnections(svgGroup, positions) {
        this.familyData.relationships.forEach(relationship => {
            const fromPos = positions[relationship.from];
            const toPos = positions[relationship.to];
            
            if (!fromPos || !toPos) return;

            // رسم خط العلاقة
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', fromPos.x);
            line.setAttribute('y1', fromPos.y + 40); // أسفل العضو
            line.setAttribute('x2', toPos.x);
            line.setAttribute('y2', toPos.y - 40); // فوق العضو
            
            const lineClass = `relationship-${relationship.type || 'default'}`;
            line.setAttribute('class', `relationship-line ${lineClass}`);
            line.setAttribute('data-relationship-id', relationship.id);
            
            svgGroup.appendChild(line);

            // إضافة نص لنوع العلاقة إذا كان معلوماً
            if (relationship.type) {
                const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                const midX = (fromPos.x + toPos.x) / 2;
                const midY = (fromPos.y + toPos.y) / 2;
                
                text.setAttribute('x', midX);
                text.setAttribute('y', midY);
                text.setAttribute('class', 'relationship-label');
                text.textContent = this.getRelationshipLabel(relationship.type);
                
                svgGroup.appendChild(text);
            }
        });
    }

    static getRelationshipLabel(type) {
        const labels = {
            'parent': 'أب/أم',
            'spouse': 'زوج/زوجة',
            'child': 'ابن/ابنة',
            'sibling': 'أخ/أخت'
        };
        
        return labels[type] || type;
    }

    static drawMembers(svgGroup, positions) {
        Object.entries(positions).forEach(([memberId, position]) => {
            const member = this.familyData.members.find(m => m.id === memberId);
            if (!member) return;

            // إنشاء مجموعة للعضو
            const memberGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
            memberGroup.setAttribute('class', 'member-node');
            memberGroup.setAttribute('data-member-id', memberId);
            memberGroup.setAttribute('transform', `translate(${position.x}, ${position.y})`);

            // الدائرة الخارجية
            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', 0);
            circle.setAttribute('cy', 0);
            circle.setAttribute('r', 40);
            circle.setAttribute('class', `member-circle ${member.gender || ''} ${member.isDeceased ? 'deceased' : ''}`);
            
            // الصورة أو الأحرف الأولى
            if (member.photo) {
                const image = document.createElementNS('http://www.w3.org/2000/svg', 'image');
                image.setAttribute('href', member.photo);
                image.setAttribute('x', -30);
                image.setAttribute('y', -30);
                image.setAttribute('width', 60);
                image.setAttribute('height', 60);
                image.setAttribute('clip-path', 'circle(30px at 30px 30px)');
                memberGroup.appendChild(image);
            } else {
                const initials = this.getMemberInitials(member);
                const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                text.setAttribute('x', 0);
                text.setAttribute('y', 5);
                text.setAttribute('text-anchor', 'middle');
                text.setAttribute('class', 'member-initials');
                text.textContent = initials;
                memberGroup.appendChild(text);
            }

            // اسم العضو
            const nameText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            nameText.setAttribute('x', 0);
            nameText.setAttribute('y', 60);
            nameText.setAttribute('text-anchor', 'middle');
            nameText.setAttribute('class', 'member-name');
            
            const displayName = member.nickname || member.firstName;
            nameText.textContent = displayName.length > 10 ? displayName.substring(0, 10) + '...' : displayName;
            
            // معلومات إضافية
            const infoText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            infoText.setAttribute('x', 0);
            infoText.setAttribute('y', 80);
            infoText.setAttribute('text-anchor', 'middle');
            infoText.setAttribute('class', 'member-info');
            
            let info = '';
            if (member.birthDate) {
                const year = new Date(member.birthDate).getFullYear();
                info += `(${year})`;
            }
            infoText.textContent = info;

            // تجميع العناصر
            memberGroup.appendChild(circle);
            memberGroup.appendChild(nameText);
            memberGroup.appendChild(infoText);
            
            svgGroup.appendChild(memberGroup);
        });
    }

    static getMemberInitials(member) {
        let initials = '';
        if (member.firstName) initials += member.firstName.charAt(0);
        if (member.lastName) initials += member.lastName.charAt(0);
        return initials || '?';
    }

    static setupEventListeners() {
        // تفاعل العقد
        this.container.addEventListener('click', (e) => {
            const memberNode = e.target.closest('.member-node');
            if (memberNode) {
                const memberId = memberNode.getAttribute('data-member-id');
                this.showMemberDetails(memberId);
            }
        });

        // التكبير والتصغير
        this.container.addEventListener('wheel', (e) => {
            e.preventDefault();
            const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
            this.zoom(zoomFactor, e.offsetX, e.offsetY);
        });

        // السحب (Pan)
        this.container.addEventListener('mousedown', (e) => {
            if (e.button === 1 || (e.button === 0 && e.ctrlKey)) { // وسطى أو يسرى + Ctrl
                e.preventDefault();
                this.isPanning = true;
                this.startPan = { x: e.clientX - this.panOffset.x, y: e.clientY - this.panOffset.y };
                this.container.style.cursor = 'grabbing';
            }
        });

        document.addEventListener('mousemove', (e) => {
            if (this.isPanning) {
                this.panOffset.x = e.clientX - this.startPan.x;
                this.panOffset.y = e.clientY - this.startPan.y;
                this.updateTransform();
            }
        });

        document.addEventListener('mouseup', () => {
            this.isPanning = false;
            this.container.style.cursor = 'grab';
        });

        // تفاعل اللمس للأجهزة المحمولة
        let touchStart = null;
        let touchStartZoom = 1;

        this.container.addEventListener('touchstart', (e) => {
            if (e.touches.length === 1) {
                touchStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
            } else if (e.touches.length === 2) {
                touchStartZoom = this.currentZoom;
            }
        });

        this.container.addEventListener('touchmove', (e) => {
            e.preventDefault();
            
            if (e.touches.length === 1 && touchStart) {
                this.panOffset.x += e.touches[0].clientX - touchStart.x;
                this.panOffset.y += e.touches[0].clientY - touchStart.y;
                touchStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
                this.updateTransform();
            }
        });
    }

    static setupControls() {
        const controls = document.querySelector('#tree-controls');
        if (!controls) return;

        // زر التكبير
        controls.querySelector('#zoom-in').addEventListener('click', () => {
            this.zoom(1.2);
        });

        // زر التصغير
        controls.querySelector('#zoom-out').addEventListener('click', () => {
            this.zoom(0.8);
        });

        // إعادة التعيين
        controls.querySelector('#reset-view').addEventListener('click', () => {
            this.resetView();
        });

        // تغيير التنسيق
        const layoutSelect = controls.querySelector('#layout-select');
        if (layoutSelect) {
            layoutSelect.addEventListener('change', (e) => {
                this.changeLayout(e.target.value);
            });
        }

        // تصفية الجيل
        const generationFilter = controls.querySelector('#generation-filter');
        if (generationFilter) {
            generationFilter.addEventListener('change', (e) => {
                this.filterByGeneration(e.target.value);
            });
        }
    }

    static zoom(factor, centerX, centerY) {
        const oldZoom = this.currentZoom;
        this.currentZoom = Math.max(0.5, Math.min(3, this.currentZoom * factor));

        if (centerX !== undefined && centerY !== undefined) {
            const containerRect = this.container.getBoundingClientRect();
            const relativeX = (centerX - containerRect.left) / oldZoom;
            const relativeY = (centerY - containerRect.top) / oldZoom;
            
            this.panOffset.x = centerX - (relativeX * this.currentZoom);
            this.panOffset.y = centerY - (relativeY * this.currentZoom);
        }

        this.updateTransform();
    }

    static pan(dx, dy) {
        this.panOffset.x += dx;
        this.panOffset.y += dy;
        this.updateTransform();
    }

    static updateTransform() {
        const svg = document.querySelector('#tree-svg');
        if (svg) {
            svg.style.transform = `scale(${this.currentZoom}) translate(${this.panOffset.x}px, ${this.panOffset.y}px)`;
        }
    }

    static resetView() {
        this.currentZoom = 1;
        this.panOffset = { x: 0, y: 0 };
        this.updateTransform();
    }

    static changeLayout(layoutType) {
        // يمكن إضافة تخطيطات مختلفة هنا
        switch(layoutType) {
            case 'vertical':
                // تخطيط عمودي
                break;
            case 'horizontal':
                // تخطيط أفقي
                break;
            case 'radial':
                // تخطيط دائري
                break;
        }
        
        this.renderTree();
    }

    static filterByGeneration(generation) {
        const allNodes = document.querySelectorAll('.member-node');
        
        allNodes.forEach(node => {
            const memberId = node.getAttribute('data-member-id');
            const member = this.familyData.members.find(m => m.id === memberId);
            
            if (generation === 'all' || (member && member.generation == generation)) {
                node.style.opacity = '1';
            } else {
                node.style.opacity = '0.3';
            }
        });
    }

    static showMemberDetails(memberId) {
        const member = this.familyData.members.find(m => m.id === memberId);
        if (!member) return;

        // إنشاء نافذة منبثقة أو تحديث جزء التفاصيل
        const detailsPanel = document.querySelector('#member-details') || this.createDetailsPanel();
        
        detailsPanel.innerHTML = `
            <div class="details-header">
                <h3>${member.firstName} ${member.lastName}</h3>
                <button class="btn-close-details">&times;</button>
            </div>
            <div class="details-content">
                <div class="member-photo">
                    ${member.photo ? `<img src="${member.photo}" alt="${member.firstName}">` : 
                      `<div class="avatar-placeholder ${member.gender}">
                         ${member.gender === 'female' ? '👩' : '👨'}
                       </div>`}
                </div>
                <div class="member-info-grid">
                    <div class="info-item">
                        <span class="label">الاسم الكامل:</span>
                        <span class="value">${member.firstName} ${member.middleName || ''} ${member.lastName}</span>
                    </div>
                    ${member.nickname ? `
                    <div class="info-item">
                        <span class="label">اللقب:</span>
                        <span class="value">${member.nickname}</span>
                    </div>` : ''}
                    ${member.birthDate ? `
                    <div class="info-item">
                        <span class="label">تاريخ الميلاد:</span>
                        <span class="value">${member.birthDate}</span>
                    </div>` : ''}
                    ${member.birthPlace ? `
                    <div class="info-item">
                        <span class="label">مكان الميلاد:</span>
                        <span class="value">${member.birthPlace}</span>
                    </div>` : ''}
                    ${member.gender ? `
                    <div class="info-item">
                        <span class="label">الجنس:</span>
                        <span class="value">${member.gender === 'male' ? 'ذكر' : 'أنثى'}</span>
                    </div>` : ''}
                    ${member.maritalStatus ? `
                    <div class="info-item">
                        <span class="label">الحالة الاجتماعية:</span>
                        <span class="value">${this.getMaritalStatusLabel(member.maritalStatus)}</span>
                    </div>` : ''}
                    ${member.isDeceased ? `
                    <div class="info-item">
                        <span class="label">تاريخ الوفاة:</span>
                        <span class="value">${member.deathDate || 'غير محدد'}</span>
                    </div>` : ''}
                    ${member.bio ? `
                    <div class="info-item full-width">
                        <span class="label">السيرة الذاتية:</span>
                        <p class="value bio">${member.bio}</p>
                    </div>` : ''}
                </div>
                <div class="details-actions">
                    <button class="btn btn-primary btn-edit-member" data-member-id="${memberId}">
                        تعديل المعلومات
                    </button>
                    <button class="btn btn-secondary btn-view-relations" data-member-id="${memberId}">
                        عرض العلاقات
                    </button>
                </div>
            </div>
        `;

        detailsPanel.classList.remove('hidden');
        
        // إضافة مستمعي الأحداث للأزرار
        detailsPanel.querySelector('.btn-close-details').addEventListener('click', () => {
            detailsPanel.classList.add('hidden');
        });

        detailsPanel.querySelector('.btn-edit-member').addEventListener('click', () => {
            FamilyDataUI.editMember(memberId);
            App.navigateTo('dashboard');
        });
    }

    static createDetailsPanel() {
        const panel = document.createElement('div');
        panel.id = 'member-details';
        panel.className = 'member-details-panel';
        document.querySelector('.tree-view').appendChild(panel);
        return panel;
    }

    static getMaritalStatusLabel(status) {
        const labels = {
            'single': 'أعزب',
            'married': 'متزوج',
            'divorced': 'مطلق',
            'widowed': 'أرمل'
        };
        return labels[status] || status;
    }

    static renderTreeInfo() {
        const infoContainer = document.querySelector('#tree-info');
        if (!infoContainer) return;

        const stats = FamilyDataService.getFamilyStatistics(this.user.id);
        
        infoContainer.innerHTML = `
            <div class="tree-stats">
                <h4>معلومات الشجرة</h4>
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-label">عدد الأعضاء:</span>
                        <span class="stat-value">${stats.totalMembers}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">عدد الأجيال:</span>
                        <span class="stat-value">${stats.generations.length}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">الأحياء:</span>
                        <span class="stat-value">${stats.livingMembers}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">المتوفون:</span>
                        <span class="stat-value">${stats.deceasedMembers}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">الذكور:</span>
                        <span class="stat-value">${stats.males}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">الإناث:</span>
                        <span class="stat-value">${stats.females}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">متوسط العمر:</span>
                        <span class="stat-value">${stats.averageAge} سنة</span>
                    </div>
                </div>
            </div>
        `;
    }

    static refresh() {
        this.familyData = FamilyDataService.loadFamilyData(this.user.id);
        this.renderTree();
    }
}

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    if (window.App && App.currentView === 'tree') {
        TreeView.init();
    }
});